
package BaseDeDatos;


public class DatosClinica {
    
}
