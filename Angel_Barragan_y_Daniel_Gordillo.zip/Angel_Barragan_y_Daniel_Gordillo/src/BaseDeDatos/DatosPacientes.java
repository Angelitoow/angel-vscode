package BaseDeDatos;

import Clases.*;

public class DatosPacientes {

    private Paciente pacientes[] = new Paciente[60];
 
    public boolean registrarPaciente(Paciente paciente) {
        for (int i = 0; i < pacientes.length; i++) {
            if (pacientes[i] == null) {
                pacientes[i] = paciente;
                return true;
            }
        }
        return false;
    }

    public boolean eliminarPacienteRegistro(long identificacion) {
        for (int i = 0; i < pacientes.length; i++) {
            if (pacientes[i] != null) {
                if (pacientes[i].getNumeroIdentidad() == identificacion) {
                    pacientes[i] = null;
                    return true;
                }

            }
        }
        return false;
    }

    public Paciente obtenerPaciente(int identificacion) {
        for (int i = 0; i < pacientes.length; i++) {
            if (pacientes[i] != null) {
                if (pacientes[i].getNumeroIdentidad() == identificacion) {
                    return pacientes[i];
                }

            }
        }
        return null;
    }
   public Paciente[] obtenerPacientes(String nombre) {
        Paciente pcs[] = new Paciente[pacientes.length];
        for (int i = 0; i < pacientes.length; i++) {
            if (pacientes[i] != null) {
                if (((pacientes[i].getNombre()+pacientes[i].getApellido()).toLowerCase()).contains(nombre.toLowerCase())) {
                    for (int j = 0; j < pcs.length; j++) {
                        if (pcs[j] == null) {
                            pcs[j] = pacientes[i];
                            break;
                        }
                    }
                }

            }
        }
        return (pcs[0] == null ? null : pcs);
    }
}
