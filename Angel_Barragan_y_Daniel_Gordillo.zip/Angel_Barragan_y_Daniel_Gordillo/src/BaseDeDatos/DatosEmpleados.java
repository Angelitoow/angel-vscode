package BaseDeDatos;

import Clases.Empleado;

public class DatosEmpleados {

    private Empleado empleados[] = new Empleado[30];

    public boolean registrarEmpleado(Empleado empleado) {

        for (int i = 0; i < empleados.length; i++) {
            if (usuarioExiste(empleado.getUsuario())) {
                return false;
            }
            else if (empleados[i] == null) {
                empleados[i] = empleado;
                return true;

            }
        }

        return false;
    }

    public boolean usuarioExiste(String usuario) {
        for (int i = 0; i < empleados.length; i++) {
            Empleado emp = empleados[i];
            if (emp != null && emp.getUsuario().equals(usuario)){
                return true;
            }
        }
        return false;
    }

    public boolean eliminarEmpleadoRegistro(long identificacion) {
        for (int i = 0; i < empleados.length; i++) {
            if (empleados[i] != null) {
                if (empleados[i].getNumeroIdentidad() == identificacion) {
                    empleados[i] = null;
                    return true;
                }

            }
        }
        return false;
    }

    public Empleado obtenerEmpleado(long identificacion) {
        for (int i = 0; i < empleados.length; i++) {
            if (empleados[i] != null) {
                if (empleados[i].getNumeroIdentidad() == identificacion) {
                    return empleados[i];
                }

            }
        }
        return null;
    }

    public Empleado obtenerEmpleado(String usuario) {
        for (int i = 0; i < empleados.length; i++) {
            if (empleados[i] != null) {
                if (empleados[i].getUsuario().equals(usuario)) {
                    return empleados[i];
                }

            }
        }

        return null;
    }

    public boolean validarSesion(String usuario, String contra) {
        for (int i = 0; i < empleados.length; i++) {
            Empleado emp = empleados[i];
            if (emp != null) {
                if (emp.getUsuario().equals(usuario) && emp.getContrasena().equals(contra)) {
                    return true;
                }
            }
        }
        return false;
    }

}
