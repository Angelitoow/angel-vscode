/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package InterfazAll;

import Clases.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.RowFilter;

/**
 *
 * @author yacke
 */
public class Clinica extends javax.swing.JFrame {

    DefaultTableModel modelo;
    Persona ingreso;
    Persona ingreso2;
    Hospital hospital = new Hospital();
    private TableRowSorter trsFiltro;
    String filtro;

    /**
     * Creates new form Clinica
     */
    public Clinica() {
        initComponents();
        llenarcamillas();

    }

    public void Guardar() {
        int id = Integer.parseInt(jTextField3.getText());
        if (!jTextField3.getText().isBlank()) {
            int modi = jTable2.getSelectedRow();
            JOptionPane.showMessageDialog(null, "El Paciente Ha Sido Modificado Con Éxito");
            Paciente pc = Hospital.getPacientes().obtenerPaciente(id);
            jTable2.setValueAt(jTextField6.getText(), modi, 3);//edad
            jTable2.setValueAt(jTextField1.getText(), modi, 5);//telefono
            jTable2.setValueAt(jTextField4.getText(), modi, 2);//Apellido
            Tabla3.setValueAt(jTextField6.getText(), modi, 3);
            Tabla3.setValueAt(jTextField4.getText(), modi, 2);
            Tabla3.setValueAt(jComboBox3.getSelectedItem(), modi, 5);
            Tabla6.setValueAt(jTextField6.getText(), modi, 3);
            Tabla6.setValueAt(jTextField4.getText(), modi, 2);
            Tabla6.setValueAt(jComboBox3.getSelectedItem(), modi, 5);
            pc.setCorreo(jTextField7.getText());
            pc.setEps(jComboBox3.getSelectedItem() + "");
            pc.setNumeroTelefono(Long.parseLong(jTextField1.getText()));
            pc.setEdad(Integer.parseInt(jTextField6.getText()));
            pc.setApellido(jTextField4.getText());
            borrar();
        }

    }

    public void GuardarMed() {
        int id = Integer.parseInt(jTextField3.getText());
        if (!jTextField3.getText().isBlank()) {
            int modi = jTable2.getSelectedRow();
            JOptionPane.showMessageDialog(null, "El Paciente Ha Sido Modificado Con Éxito");
            Paciente pc = Hospital.getPacientes().obtenerPaciente(id);
            jTable2.setValueAt(jTextArea1.getText(), modi, 6);
            pc.setPeso(Float.parseFloat(jTextField9.getText() + ""));
            pc.setTipoSangre(jComboBox4.getSelectedItem() + "");
            pc.setEstatura(Float.parseFloat(jTextField8.getText() + ""));
            pc.setDiagnostico(jTextArea1.getText());
            borrar();
        }
    }

    public void borrar() {
        jTextField5.setText("");
        jTextField4.setText("");
        jTextField3.setText("");
        jTextField1.setText("");
        jTextField6.setText("");
        jTextField7.setText("");
        jTextField8.setText("");
        jTextField9.setText("");
        jTextArea1.setText("");
        jComboBox2.setSelectedIndex(0);
        jComboBox3.setSelectedIndex(0);
        jComboBox4.setSelectedIndex(0);
        jTextField5.setEnabled(false);
        jTextField4.setEnabled(false);
        jTextField3.setEnabled(false);
        jTextField1.setEnabled(false);
        jTextField6.setEnabled(false);
        jTextField7.setEnabled(false);
        jTextField8.setEnabled(false);
        jTextField9.setEnabled(false);
        jTextArea1.setEnabled(false);
        jComboBox2.setEnabled(false);
        jComboBox3.setEnabled(false);
        jComboBox4.setEnabled(false);
    }

    public void ModificarMed() {
        int modi = jTable2.getSelectedRow();
        if (modi != -1) {
            int id = Integer.parseInt((jTable2.getValueAt(modi, 0)).toString());
            Paciente pc = Hospital.getPacientes().obtenerPaciente(id);
            int a = JOptionPane.YES_NO_OPTION;
            int b = JOptionPane.showConfirmDialog(null, "¿Estas Seguro Que Quieres Modificar El Paciente?", "Modificacion", a);
            if (b == JOptionPane.YES_OPTION) {
                jTextField5.setText(pc.getNombre());
                jTextField4.setText(pc.getApellido());
                jTextField3.setText(pc.getNumeroIdentidad() + "");
                jTextField1.setText(pc.getNumeroTelefono() + "");
                jTextField6.setText(pc.getEdad() + "");
                jTextField7.setText(pc.getCorreo());
                jTextField8.setText(pc.getEstatura() + "");
                jTextField8.setEnabled(true);
                jTextField9.setText(pc.getPeso() + "");
                jTextField9.setEnabled(true);
                jTextArea1.setText(pc.getDiagnostico());
                jTextArea1.setEnabled(true);
                jComboBox2.setSelectedIndex((pc.getGenero() == true) ? 1 : 2);
                jComboBox3.setSelectedIndex((pc.getEps().equalsIgnoreCase("NUEVA EPS")) ? 1 : (pc.getEps().equalsIgnoreCase("SANITAS")) ? 2 : (pc.getEps().equalsIgnoreCase("SEGURAS")) ? 3 : (pc.getEps().equalsIgnoreCase("PARTICULAR")) ? 4 : 5);
                jComboBox4.setSelectedIndex((pc.getTipoSangre() == null) ? 0 : (pc.getTipoSangre().equalsIgnoreCase("0+")) ? 1 : (pc.getTipoSangre().equalsIgnoreCase("A+")) ? 2 : (pc.getTipoSangre().equalsIgnoreCase("B+")) ? 3 : (pc.getTipoSangre().equalsIgnoreCase("AB")) ? 4 : (pc.getTipoSangre().equalsIgnoreCase("A-")) ? 5 : (pc.getTipoSangre().equalsIgnoreCase("B-")) ? 6 : 7);
                jComboBox4.setEnabled(true);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No Se Puede Modificar Sin Seleccionar Ningún Paciente");
        }

    }

    public void Modificar() {
        int modi = jTable2.getSelectedRow();
        if (modi != -1) {
            int id = Integer.parseInt((jTable2.getValueAt(modi, 0)).toString());
            Paciente pc = Hospital.getPacientes().obtenerPaciente(id);
            int a = JOptionPane.YES_NO_OPTION;
            int b = JOptionPane.showConfirmDialog(null, "¿Estas Seguro Que Quieres Modificar El Paciente?", "Modificacion", a);
            if (b == JOptionPane.YES_OPTION) {
                jTextField5.setText(pc.getNombre());
                jTextField4.setText(pc.getApellido());
                jTextField4.setEnabled(true);
                jTextField3.setText(pc.getNumeroIdentidad() + "");
                jTextField1.setText(pc.getNumeroTelefono() + "");
                jTextField1.setEnabled(true);
                jTextField6.setText(pc.getEdad() + "");
                jTextField6.setEnabled(true);
                jTextField7.setText(pc.getCorreo());
                jTextField7.setEnabled(true);
                jTextField8.setText(pc.getEstatura() + "");
                jTextField9.setText(pc.getPeso() + "");
                jTextArea1.setText(pc.getDiagnostico());
                jComboBox2.setSelectedIndex((pc.getGenero() == true) ? 1 : 2);
                jComboBox3.setSelectedIndex((pc.getEps().equalsIgnoreCase("NUEVA EPS")) ? 1 : (pc.getEps().equalsIgnoreCase("SANITAS")) ? 2 : (pc.getEps().equalsIgnoreCase("SEGURAS")) ? 3 : (pc.getEps().equalsIgnoreCase("PARTICULAR")) ? 4 : 5);
                jComboBox3.setEnabled(true);
                jComboBox4.setSelectedIndex((pc.getTipoSangre() == null) ? 0 : (pc.getTipoSangre().equalsIgnoreCase("0+")) ? 1 : (pc.getTipoSangre().equalsIgnoreCase("A+")) ? 2 : (pc.getTipoSangre().equalsIgnoreCase("B+")) ? 3 : (pc.getTipoSangre().equalsIgnoreCase("AB")) ? 4 : (pc.getTipoSangre().equalsIgnoreCase("A-")) ? 5 : (pc.getTipoSangre().equalsIgnoreCase("B-")) ? 6 : 7);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No Se Puede Modificar Sin Seleccionar Ningún Paciente");
        }

    }

    public void cargarDatos() {
        ((DefaultTableModel) Tabla5.getModel()).setNumRows(0);
        if (ingreso != null) {
            PersonalMedico medico = (PersonalMedico) ingreso;
            Camilla camillas[] = Hospital.getHabitaciones()[medico.getHabitacion()[0]][medico.getHabitacion()[1]].getCamillas();
            for (Camilla cm : camillas) {
                if (cm != null) {
                    if (cm.isEstado()) {
                        Paciente pc = cm.getPaciente();
                        Object datos[] = {pc.getNumeroIdentidad(), pc.getNombre(), pc.getApellido(), pc.getEdad(), (pc.getGenero() ? "Masculino" : "Femenino")};
                        llenarTabla(Tabla5, datos);
                    }
                }
            }
        }
    }

    public void llenarcamillas() {
        Habitacion pisos[][] = Hospital.getHabitaciones();
        HabitacionesCompletas.removeAll();
        for (int i = 0; i < pisos.length; i++) {
            for (int j = 0; j < pisos[i].length; j++) {
                JPanel panelCamillas = new JPanel();
                panelCamillas.setLayout(pHabitacionJPanel.getLayout());
                panelCamillas.setBackground(Color.white);
                Color cl = new Color(101, 38, 209);
                JButton titulo = new JButton("Habitación " + (i + 1) + "0" + (j + 1));
                titulo.setBackground(cl);
                final int y1 = i, z = j;
                titulo.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        JButton boton = (JButton) e.getSource();
                        JPanel p = (JPanel) boton.getParent();
                        for (Component xd : p.getComponents()) {
                            xd.setEnabled(false);
                        }
                        pisos[y1][z].setEstado(false);
                    }
                });
                panelCamillas.add(titulo);
                for (int k = 0; k < 5; k++) {
                    if (pisos[i][j].getCamillas()[k] != null) {
                        JButton boton = new JButton("Camilla " + (k + 1));
                        if (pisos[i][j].getCamillas()[k].isEstado()) {
                            boton.setBackground(new Color(222, 108, 131));
                        } else {
                            boton.setBackground(new Color(28, 168, 214));
                        }
                        panelCamillas.add(boton);
                    } else {
                        Color color = new Color(240, 85, 242);
                        JButton bt = new JButton("+");
                        final int x = i;
                        final int y = j;
                        bt.addActionListener(new ActionListener() {

                            @Override
                            public void actionPerformed(ActionEvent e) {
                                Hospital.getHabitaciones()[x][y].addCamilla();
                                llenarcamillas();

                            }
                        });
                        bt.setBackground(color);
                        panelCamillas.add(bt);
                    }

                }
                if (!pisos[i][j].isEstado()) {
                    for (Component xd : panelCamillas.getComponents()) {
                        xd.setEnabled(false);
                    }
                }
                HabitacionesCompletas.add(panelCamillas);
            }
        }
        this.revalidate();
        this.repaint();

    }

    public void llenarTabla(JTable tabla, Object[] Datos) {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();

        modelo.addRow(Datos);
    }

    public String ConfirmacionPersonalMed() {
        String errores = "";
        if (textField1.getText().isBlank()) {
            errores += "\nEl campo de Nombre esta vacio";
        }
        if (textField2.getText().isBlank()) {
            errores += "\nEl campo de Apellido esta vacio";
        }
        if (SelecGenero.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado género";
        }
        if (textField3.getText().isBlank()) {
            errores += "\nEl campo de edad esta vacio";
        } else if (textField3.getText().charAt(0) == '0' || Integer.parseInt(textField3.getText()) < 18 || Integer.parseInt(textField3.getText()) > 70) {
            errores += "\nEdad invalida para Trabajar en la Clinica";
        }
        if (textField5.getText().isBlank()) {
            errores += "\nEl campo de telefono esta vacio";
        } else if (textField5.getText().length() != 10) {
            errores += "\nEl campo de telefono es inválido";
        }
        if (textField6.getText().isBlank()) {
            errores += "\nEl campo de cédula esta vacio";
        } else if (textField6.getText().length() < 6 || textField6.getText().length() > 12) {
            errores += "\nEl campo de cédula es inválido";
        } else if (Hospital.getPacientes().obtenerPaciente(Integer.parseInt(textField6.getText())) != null) {
            errores += "El Empleado ya se encuentra registrado";
        }

        if (SelecEspe.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado Ninguna Especialidad";
        }
        if (jRadioButton1.isSelected() == true && textField3.getText().isBlank()) {
            errores += "\nNo se ha digitado Ninguna edad, No existe tipo de documento";
        } else if (jRadioButton1.isSelected() == false) {
            errores += "\nNo se ha seleccionado que tipo de documento es";
        } else if (Integer.parseInt(textField3.getText()) < 18 && jRadioButton1.isSelected() == true) {
            errores += "\nEmpleado Inválido";
        }
        if (textField29.getText().isBlank()) {
            errores += "\nEl campo de Usuario esta vacio";
        }
        if (textField30.getText().isBlank()) {
            errores += "\nEl campo de Contraseña esta vacio";
        }

        return errores;

    }

    public String ConfirmacionPersonalAdmini() {
        String errores = "";
        if (textField4.getText().isBlank()) {
            errores += "\nEl campo de Nombre esta vacio";
        }
        if (textField7.getText().isBlank()) {
            errores += "\nEl campo de Apellido esta vacio";
        }
        if (SelecGenero1.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado género";
        }
        if (textField8.getText().isBlank()) {
            errores += "\nEl campo de edad esta vacio";
        } else if (textField8.getText().charAt(0) == '0' || Integer.parseInt(textField8.getText()) < 18 || Integer.parseInt(textField8.getText()) > 70) {
            errores += "\nEdad invalida para Trabajar en la Clinica";
        }
        if (textField9.getText().isBlank()) {
            errores += "\nEl campo de telefono esta vacio";
        } else if (textField9.getText().length() != 10) {
            errores += "\nEl campo de telefono es inválido";
        }
        if (textField10.getText().isBlank()) {
            errores += "\nEl campo de cédula esta vacio";
        } else if (textField10.getText().length() < 6 || textField10.getText().length() > 12) {
            errores += "\nEl campo de cédula es inválido";
        } else if (Hospital.getPacientes().obtenerPaciente(Integer.parseInt(textField10.getText())) != null) {
            errores += "El Empleado ya se encuentra registrado";
        }

        if (SelecCargo.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado Ningún Cargo";
        }
        if (jRadioButton3.isSelected() == true && textField8.getText().isBlank()) {
            errores += "\nNo se ha digitado Ninguna edad, No existe tipo de documento";
        } else if (jRadioButton3.isSelected() == false) {
            errores += "\nNo se ha seleccionado que tipo de documento es";
        } else if (Integer.parseInt(textField8.getText()) < 18 && jRadioButton3.isSelected() == true) {
            errores += "\nEmpleado Inválido";
        }
        if (textField31.getText().isBlank()) {
            errores += "\nEl campo de Usuario esta vacio";
        }
        if (textField32.getText().isBlank()) {
            errores += "\nEl campo de Contraseña esta vacio";
        }

        return errores;
    }

    public String ConfirmacionMenuPaciente() {
        String errores = "";
        if (textField11.getText().isBlank()) {
            errores += "\nEl campo de Nombre esta vacio";
        }
        if (textField12.getText().isBlank()) {
            errores += "\nEl campo de Apellido esta vacio";
        }
        if (SelecGenero2.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado género";
        }
        if (textField13.getText().isBlank()) {
            errores += "\nEl campo de edad esta vacio";
        } else if (textField13.getText().charAt(0) == '0' || Integer.parseInt(textField13.getText()) <= 0 || Integer.parseInt(textField13.getText()) > 110) {
            errores += "\nEdad invalida";
        }
        if (textField15.getText().isBlank()) {
            errores += "\nEl campo de telefono esta vacio";
        } else if (textField15.getText().length() != 10) {
            errores += "\nEl campo de telefono es inválido";
        }
        if (textField16.getText().isBlank()) {
            errores += "\nEl campo de cédula esta vacio";
        } else if (textField16.getText().length() < 6 || textField16.getText().length() > 12) {
            errores += "\nEl campo de cédula es inválido";
        } else if (Hospital.getPacientes().obtenerPaciente(Integer.parseInt(textField16.getText())) != null) {
            errores += "El paciente ya se encuentra registrado";
        }

        if (textField14.getText().isBlank()) {
            errores += "\nEl campo del correo esta vacio";
        } else if ((!textField14.getText().endsWith("@gmail.com")) || textField14.getText().length() < 11) {
            errores += "\nEL campo del correo no es válido";
        }
        if (SelecEps.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado ninguna Eps";
        }
        if ((jRadioButton5.isSelected() == true && textField13.getText().isBlank()) || (jRadioButton6.isSelected() == true && textField13.getText().isBlank())) {
            errores += "\nNo se ha digitado Ninguna edad, No existe tipo de documento";
        } else if (jRadioButton5.isSelected() == false && jRadioButton6.isSelected() == false) {
            errores += "\nNo se ha seleccionado que tipo de documento es";
        } else if (Integer.parseInt(textField13.getText()) >= 18 && jRadioButton5.isSelected() == true) {
            errores += "\nTipo de documento Inválido";
        } else if (Integer.parseInt(textField13.getText()) < 18 && jRadioButton6.isSelected() == true) {
            errores += "\nTipo de documento Inválido";
        }

        return errores;
    }

    public String confirmacionMenuPaciente2() {
        String errores = "";
        if (textField23.getText().isBlank()) {
            errores += "\nEl campo de Nombre esta vacio";
        }
        if (textField24.getText().isBlank()) {
            errores += "\nEl campo de Apellido esta vacio";
        }
        if (SelecGenero3.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado género";
        }
        if (textField25.getText().isBlank()) {
            errores += "\nEl campo de edad esta vacio";
        } else if (textField25.getText().charAt(0) == '0' || Integer.parseInt(textField25.getText()) <= 0 || Integer.parseInt(textField25.getText()) > 110) {
            errores += "\nEdad invalida";
        }
        if (textField27.getText().isBlank()) {
            errores += "\nEl campo de telefono esta vacio";
        } else if (textField27.getText().length() != 10) {
            errores += "\nEl campo de telefono es inválido";
        }
        if (textField28.getText().isBlank()) {
            errores += "\nEl campo de cédula esta vacio";
        } else if (textField28.getText().length() < 6 || textField28.getText().length() > 12) {
            errores += "\nEl campo de cédula es inválido";
        } else if (Hospital.getPacientes().obtenerPaciente(Integer.parseInt(textField28.getText())) != null) {
            errores += "El paciente ya se encuentra registrado";
        }

        if (textField26.getText().isBlank()) {
            errores += "\nEl campo del correo esta vacio";
        } else if ((!textField26.getText().endsWith("@gmail.com")) || textField26.getText().length() < 11) {
            errores += "\nEL campo del correo no es válido";
        }
        if (SelecEps1.getSelectedIndex() == 0) {
            errores += "\nNo se ha seleccionado ninguna Eps";
        }
        if ((jRadioButton7.isSelected() == true && textField25.getText().isBlank()) || (jRadioButton8.isSelected() == true && textField25.getText().isBlank())) {
            errores += "\nNo se ha digitado Ninguna edad, No existe tipo de documento";
        } else if (jRadioButton7.isSelected() == false && jRadioButton8.isSelected() == false) {
            errores += "\nNo se ha seleccionado que tipo de documento es";
        } else if (Integer.parseInt(textField25.getText()) >= 18 && jRadioButton7.isSelected() == true) {
            errores += "\nTipo de documento Inválido";
        } else if (Integer.parseInt(textField25.getText()) < 18 && jRadioButton8.isSelected() == true) {
            errores += "\nTipo de documento Inválido";
        }

        return errores;
    }

    public void limpiar() {
        jTextField2.setText("");
        jPasswordField1.setText("");
        if (jTextField2.getText().equals("Ingrese Su Nombre De Usuario")) {
            jTextField2.setText("");
            jTextField2.setForeground(Color.black);
        }

        if (String.valueOf(jPasswordField1.getPassword()).isEmpty()) {
            jPasswordField1.setText("******");
            jPasswordField1.setForeground(Color.gray);
        }
    }

    public void cerrarSesion() {

        int salida = JOptionPane.showConfirmDialog(null, "Estas Seguro Que Quieres Cerrar Sesion", "Cerrar Sesión", JOptionPane.YES_NO_OPTION);
        if (salida == 0) {
            this.setVisible(false);
            Padre.removeAll();
            Padre.add(PanelLogin);
            Padre.repaint();
            Padre.revalidate();
            this.setVisible(true);
        } else {
            this.setVisible(true);
        }
    }

    public void eliminarTabla(JTable tabla) {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        int eli = tabla.getSelectedRow();
        if (eli != -1) {
            modelo.removeRow(eli);
        } else {
            JOptionPane.showMessageDialog(null, "No Hay Datos Que Eliminar");
        }

    }

    public void PasarMedico(JTable tabla, Object[] Datos) {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.addRow(Datos);
        int eli = tabla.getSelectedRow();
        if (eli != -1) {
            modelo.removeRow(eli);
        } else {
            JOptionPane.showMessageDialog(null, "No Hay Datos Que Enviar");
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Padre = new javax.swing.JPanel();
        PanelLogin = new javax.swing.JPanel();
        jLabel100 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        jLabel102 = new javax.swing.JLabel();
        jLabel104 = new javax.swing.JLabel();
        jLabel105 = new javax.swing.JLabel();
        jLabel106 = new javax.swing.JLabel();
        jLabel103 = new javax.swing.JLabel();
        jLabel107 = new javax.swing.JLabel();
        jLabel112 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel108 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel109 = new javax.swing.JLabel();
        jLabel110 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        PanelAdmin = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        BtnInhabilitar = new javax.swing.JButton();
        BtnPaciente = new javax.swing.JButton();
        BtnCamilla = new javax.swing.JButton();
        BtnInforme = new javax.swing.JButton();
        BtnDoctor = new javax.swing.JButton();
        BtnPersonalAdmin = new javax.swing.JButton();
        jLabel64 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        BtnCerrarSesion = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        Cargo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        PanelMed = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel69 = new javax.swing.JLabel();
        BtnPaciente1 = new javax.swing.JButton();
        BtnBuscar = new javax.swing.JButton();
        jLabel70 = new javax.swing.JLabel();
        jLabel71 = new javax.swing.JLabel();
        jLabel72 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        Nombre2 = new javax.swing.JLabel();
        jLabel73 = new javax.swing.JLabel();
        BtnCerrarSesion1 = new javax.swing.JButton();
        Cargo2 = new javax.swing.JLabel();
        jLabel74 = new javax.swing.JLabel();
        PanelPersonalAdmini = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel88 = new javax.swing.JLabel();
        BtnPaciente2 = new javax.swing.JButton();
        BtnBuscar1 = new javax.swing.JButton();
        jLabel89 = new javax.swing.JLabel();
        jLabel90 = new javax.swing.JLabel();
        jLabel91 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        BtnCerrarSesion2 = new javax.swing.JButton();
        Nombre3 = new javax.swing.JLabel();
        jLabel92 = new javax.swing.JLabel();
        Cargo3 = new javax.swing.JLabel();
        jLabel93 = new javax.swing.JLabel();
        AggPac1 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        textField11 = new java.awt.TextField();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        textField12 = new java.awt.TextField();
        textField13 = new java.awt.TextField();
        textField14 = new java.awt.TextField();
        textField15 = new java.awt.TextField();
        SelecGenero2 = new javax.swing.JComboBox<>();
        PasarHa = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        textField16 = new java.awt.TextField();
        Agregar2 = new javax.swing.JButton();
        SelecEps = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        Tabla3 = new javax.swing.JTable();
        jLabel48 = new javax.swing.JLabel();
        Regresar4 = new javax.swing.JButton();
        jLabel49 = new javax.swing.JLabel();
        Automatizado = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel50 = new javax.swing.JLabel();
        AggPac2 = new javax.swing.JPanel();
        jLabel51 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        textField17 = new java.awt.TextField();
        jLabel52 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel55 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        textField18 = new java.awt.TextField();
        textField19 = new java.awt.TextField();
        textField20 = new java.awt.TextField();
        textField21 = new java.awt.TextField();
        SelecGenero4 = new javax.swing.JComboBox<>();
        GUARDAR = new javax.swing.JButton();
        jLabel58 = new javax.swing.JLabel();
        jLabel59 = new javax.swing.JLabel();
        textArea1 = new java.awt.TextArea();
        textField22 = new java.awt.TextField();
        jLabel60 = new javax.swing.JLabel();
        ABRIR = new javax.swing.JButton();
        jLabel61 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        ELIMINAR = new javax.swing.JButton();
        jLabel62 = new javax.swing.JLabel();
        Regresar5 = new javax.swing.JButton();
        jLabel63 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Tabla5 = new javax.swing.JTable();
        jLabel65 = new javax.swing.JLabel();
        jLabel66 = new javax.swing.JLabel();
        AggPac3 = new javax.swing.JPanel();
        jLabel75 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        textField23 = new java.awt.TextField();
        jLabel76 = new javax.swing.JLabel();
        jLabel77 = new javax.swing.JLabel();
        jLabel78 = new javax.swing.JLabel();
        jLabel79 = new javax.swing.JLabel();
        jLabel80 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        textField24 = new java.awt.TextField();
        textField25 = new java.awt.TextField();
        textField26 = new java.awt.TextField();
        textField27 = new java.awt.TextField();
        SelecGenero3 = new javax.swing.JComboBox<>();
        PasarHab2 = new javax.swing.JButton();
        jLabel82 = new javax.swing.JLabel();
        jRadioButton7 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jLabel83 = new javax.swing.JLabel();
        jLabel84 = new javax.swing.JLabel();
        textField28 = new java.awt.TextField();
        Agregar5 = new javax.swing.JButton();
        SelecEps1 = new javax.swing.JComboBox<>();
        jLabel85 = new javax.swing.JLabel();
        Regresar7 = new javax.swing.JButton();
        jLabel86 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        Tabla6 = new javax.swing.JTable();
        jLabel87 = new javax.swing.JLabel();
        AggPersonalAdmini = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        Regresar2 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        textField4 = new java.awt.TextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        textField7 = new java.awt.TextField();
        textField8 = new java.awt.TextField();
        textField9 = new java.awt.TextField();
        SelecGenero1 = new javax.swing.JComboBox<>();
        jLabel30 = new javax.swing.JLabel();
        jRadioButton3 = new javax.swing.JRadioButton();
        jLabel31 = new javax.swing.JLabel();
        textField10 = new java.awt.TextField();
        Agregar1 = new javax.swing.JButton();
        SelecCargo = new javax.swing.JComboBox<>();
        Eliminar1 = new javax.swing.JButton();
        jLabel98 = new javax.swing.JLabel();
        jLabel99 = new javax.swing.JLabel();
        textField31 = new java.awt.TextField();
        textField32 = new java.awt.TextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        Tabla2 = new javax.swing.JTable();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        AggPersonalMed = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        Regresar1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        textField1 = new java.awt.TextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        textField2 = new java.awt.TextField();
        textField3 = new java.awt.TextField();
        textField5 = new java.awt.TextField();
        SelecGenero = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel19 = new javax.swing.JLabel();
        textField6 = new java.awt.TextField();
        Agregar = new javax.swing.JButton();
        SelecEspe = new javax.swing.JComboBox<>();
        Eliminar = new javax.swing.JButton();
        textField29 = new java.awt.TextField();
        textField30 = new java.awt.TextField();
        jLabel96 = new javax.swing.JLabel();
        jLabel97 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla1 = new javax.swing.JTable();
        Automatico = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        InhHab = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        Regresar = new javax.swing.JButton();
        jLabel114 = new javax.swing.JLabel();
        jLabel113 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        HabitacionesCompletas = new javax.swing.JPanel();
        pHabitacionJPanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        BuscarPac2 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jLabel115 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel116 = new javax.swing.JLabel();
        buscarID = new javax.swing.JTextField();
        jPanel23 = new javax.swing.JPanel();
        Buscar = new javax.swing.JButton();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel117 = new javax.swing.JLabel();
        jLabel118 = new javax.swing.JLabel();
        jLabel119 = new javax.swing.JLabel();
        jLabel120 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        jLabel123 = new javax.swing.JLabel();
        jLabel124 = new javax.swing.JLabel();
        jLabel125 = new javax.swing.JLabel();
        jLabel126 = new javax.swing.JLabel();
        jLabel127 = new javax.swing.JLabel();
        jLabel128 = new javax.swing.JLabel();
        jLabel129 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jComboBox3 = new javax.swing.JComboBox<>();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel130 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel94 = new javax.swing.JLabel();
        Regresar8 = new javax.swing.JButton();
        jLabel95 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        Padre.setBackground(new java.awt.Color(0, 153, 153));
        Padre.setForeground(new java.awt.Color(0, 153, 153));
        Padre.setMaximumSize(new java.awt.Dimension(1310, 854));
        Padre.setMinimumSize(new java.awt.Dimension(1310, 854));
        Padre.setPreferredSize(new java.awt.Dimension(1310, 854));
        Padre.setLayout(new java.awt.CardLayout());

        PanelLogin.setBackground(new java.awt.Color(255, 255, 255));
        PanelLogin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel100.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/logo.png"))); // NOI18N
        jLabel100.setText("jLabel2");
        PanelLogin.add(jLabel100, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 80, 150, 150));

        jLabel101.setFont(new java.awt.Font("Segoe UI Black", 3, 24)); // NOI18N
        jLabel101.setForeground(new java.awt.Color(255, 255, 255));
        jLabel101.setText("HOSPITAL ÁNGEL");
        PanelLogin.add(jLabel101, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, 230, 40));

        jLabel102.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        PanelLogin.add(jLabel102, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 490, 150, 150));

        jLabel104.setFont(new java.awt.Font("Segoe UI Black", 3, 36)); // NOI18N
        jLabel104.setForeground(new java.awt.Color(0, 153, 153));
        jLabel104.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/favicon.png"))); // NOI18N
        jLabel104.setText("LOGIN");
        PanelLogin.add(jLabel104, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, 180, 40));

        jLabel105.setFont(new java.awt.Font("Segoe UI Black", 3, 48)); // NOI18N
        jLabel105.setForeground(new java.awt.Color(0, 153, 153));
        jLabel105.setText("INICIAR SESIÓN");
        PanelLogin.add(jLabel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 120, -1, -1));

        jLabel106.setFont(new java.awt.Font("Segoe UI Emoji", 3, 24)); // NOI18N
        jLabel106.setForeground(new java.awt.Color(0, 0, 0));
        jLabel106.setText("CONTRASEÑA");
        PanelLogin.add(jLabel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 370, 170, 40));

        jLabel103.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/logo.png"))); // NOI18N
        jLabel103.setText("jLabel2");
        PanelLogin.add(jLabel103, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 80, 150, 150));

        jLabel107.setFont(new java.awt.Font("Segoe UI Emoji", 3, 24)); // NOI18N
        jLabel107.setForeground(new java.awt.Color(0, 0, 0));
        jLabel107.setText("USUARIO");
        PanelLogin.add(jLabel107, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 240, 110, 70));

        jLabel112.setFont(new java.awt.Font("Segoe UI Black", 3, 24)); // NOI18N
        jLabel112.setForeground(new java.awt.Color(255, 255, 255));
        jLabel112.setText("HOSPITAL FERIA");
        PanelLogin.add(jLabel112, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 250, 220, 40));

        jTextField2.setForeground(new java.awt.Color(153, 153, 153));
        jTextField2.setText("Ingrese Su Nombre De Usuario");
        jTextField2.setBorder(null);
        jTextField2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTextField2MousePressed(evt);
            }
        });
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        PanelLogin.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 310, 360, -1));
        PanelLogin.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 330, 360, 20));
        PanelLogin.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 450, 360, 20));

        jPasswordField1.setText("******");
        jPasswordField1.setBorder(null);
        jPasswordField1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPasswordField1MousePressed(evt);
            }
        });
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        PanelLogin.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 430, 360, -1));

        jLabel108.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/city.png"))); // NOI18N
        PanelLogin.add(jLabel108, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 500, -1, 170));

        jButton1.setBackground(new java.awt.Color(51, 153, 255));
        jButton1.setText("INGRESAR");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        PanelLogin.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 560, 190, 70));

        jLabel109.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/city.png"))); // NOI18N
        PanelLogin.add(jLabel109, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 0, -1, 500));

        jLabel110.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/city.png"))); // NOI18N
        PanelLogin.add(jLabel110, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 500));

        jLabel111.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/city.png"))); // NOI18N
        PanelLogin.add(jLabel111, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 500, -1, 180));

        Padre.add(PanelLogin, "card14");

        PanelAdmin.setBackground(new java.awt.Color(0, 153, 153));
        PanelAdmin.setForeground(new java.awt.Color(255, 255, 255));
        PanelAdmin.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(0, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        jLabel4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel4.setFont(new java.awt.Font("Stencil", 3, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(4, 3, 3));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("PANEL DE ADMINISTRADOR");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 582, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(58, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 495, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        PanelAdmin.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 590, 60));

        BtnInhabilitar.setBackground(new java.awt.Color(0, 153, 153));
        BtnInhabilitar.setForeground(new java.awt.Color(0, 0, 0));
        BtnInhabilitar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Camilla.png"))); // NOI18N
        BtnInhabilitar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnInhabilitar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnInhabilitarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnInhabilitarMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnInhabilitarMousePressed(evt);
            }
        });
        BtnInhabilitar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInhabilitarActionPerformed(evt);
            }
        });
        PanelAdmin.add(BtnInhabilitar, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 202, 180, 160));

        BtnPaciente.setBackground(new java.awt.Color(0, 153, 153));
        BtnPaciente.setForeground(new java.awt.Color(0, 0, 0));
        BtnPaciente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Paciente.png"))); // NOI18N
        BtnPaciente.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnPaciente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnPacienteMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnPacienteMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnPacienteMousePressed(evt);
            }
        });
        BtnPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnPacienteActionPerformed(evt);
            }
        });
        PanelAdmin.add(BtnPaciente, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 200, 180, 160));

        BtnCamilla.setBackground(new java.awt.Color(0, 153, 153));
        BtnCamilla.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/BuscarPaciente_Pequeño.png"))); // NOI18N
        BtnCamilla.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnCamilla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnCamillaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnCamillaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnCamillaMousePressed(evt);
            }
        });
        BtnCamilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCamillaActionPerformed(evt);
            }
        });
        PanelAdmin.add(BtnCamilla, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 460, 180, 160));

        BtnInforme.setBackground(new java.awt.Color(0, 153, 153));
        BtnInforme.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/InformeClinico.png"))); // NOI18N
        BtnInforme.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnInforme.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnInformeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnInformeMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnInformeMousePressed(evt);
            }
        });
        BtnInforme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnInformeActionPerformed(evt);
            }
        });
        PanelAdmin.add(BtnInforme, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 460, 180, 160));

        BtnDoctor.setBackground(new java.awt.Color(0, 153, 153));
        BtnDoctor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Medico.png"))); // NOI18N
        BtnDoctor.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnDoctor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnDoctorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnDoctorMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnDoctorMousePressed(evt);
            }
        });
        BtnDoctor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnDoctorActionPerformed(evt);
            }
        });
        PanelAdmin.add(BtnDoctor, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 200, 180, 160));

        BtnPersonalAdmin.setBackground(new java.awt.Color(0, 153, 153));
        BtnPersonalAdmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/PersonalAdmin.png"))); // NOI18N
        BtnPersonalAdmin.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnPersonalAdmin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnPersonalAdminMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnPersonalAdminMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnPersonalAdminMousePressed(evt);
            }
        });
        BtnPersonalAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnPersonalAdminActionPerformed(evt);
            }
        });
        PanelAdmin.add(BtnPersonalAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 460, 180, -1));

        jLabel64.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(0, 0, 0));
        jLabel64.setText("INFORME CLINICO");
        PanelAdmin.add(jLabel64, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 440, 140, 20));

        jLabel3.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("AGREGAR  PERSONAL  ADMINISTRATIVO");
        PanelAdmin.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 440, 270, 20));

        jLabel5.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("AGREGAR  PACIENTE");
        PanelAdmin.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 180, 140, 20));

        jLabel6.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("AGREGAR  PERSONAL  MEDICO");
        PanelAdmin.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 180, 210, 20));

        jLabel7.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("HABITACIONES");
        PanelAdmin.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 180, 110, 20));

        jLabel8.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("DISPONIBILIDAD");
        PanelAdmin.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 440, 140, 20));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        PanelAdmin.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 140, 150));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 4));

        BtnCerrarSesion.setBackground(new java.awt.Color(255, 0, 0));
        BtnCerrarSesion.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        BtnCerrarSesion.setText("Cerrar Sesion");
        BtnCerrarSesion.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnCerrarSesion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnCerrarSesionMouseClicked(evt);
            }
        });
        BtnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCerrarSesionActionPerformed(evt);
            }
        });

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoAdmin .png"))); // NOI18N

        Nombre.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Nombre.setForeground(new java.awt.Color(255, 255, 255));
        Nombre.setText("Nombre:");

        Cargo.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Cargo.setForeground(new java.awt.Color(255, 255, 255));
        Cargo.setText("Cargo:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(BtnCerrarSesion))
                .addGap(20, 20, 20))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Nombre)
                    .addComponent(Cargo))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Nombre)
                .addGap(2, 2, 2)
                .addComponent(Cargo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BtnCerrarSesion)
                .addContainerGap())
        );

        PanelAdmin.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1110, 20, 170, 210));

        jLabel1.setForeground(new java.awt.Color(102, 255, 204));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        PanelAdmin.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(PanelAdmin, "card2");

        PanelMed.setBackground(new java.awt.Color(0, 153, 153));
        PanelMed.setForeground(new java.awt.Color(255, 255, 255));
        PanelMed.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(0, 204, 204));
        jPanel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        jLabel69.setBackground(new java.awt.Color(255, 255, 255));
        jLabel69.setFont(new java.awt.Font("Stencil", 3, 36)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(4, 3, 3));
        jLabel69.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel69.setText("PANEL MÉDICO");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel69, javax.swing.GroupLayout.PREFERRED_SIZE, 497, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel69, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE))
        );

        PanelMed.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, 570, 60));

        BtnPaciente1.setBackground(new java.awt.Color(0, 153, 153));
        BtnPaciente1.setForeground(new java.awt.Color(0, 0, 0));
        BtnPaciente1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/PacienteGrande.png"))); // NOI18N
        BtnPaciente1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnPaciente1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnPaciente1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnPaciente1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnPaciente1MousePressed(evt);
            }
        });
        BtnPaciente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnPaciente1ActionPerformed(evt);
            }
        });
        PanelMed.add(BtnPaciente1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 330, 350));

        BtnBuscar.setBackground(new java.awt.Color(0, 153, 153));
        BtnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/BuscarPaciente.png"))); // NOI18N
        BtnBuscar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnBuscar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnBuscarMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnBuscarMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnBuscarMousePressed(evt);
            }
        });
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        PanelMed.add(BtnBuscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 220, 350, 350));

        jLabel70.setFont(new java.awt.Font("Dubai Medium", 1, 24)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(0, 0, 0));
        jLabel70.setText("INFORMACION MEDICA PACIENTE");
        PanelMed.add(jLabel70, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 390, 20));

        jLabel71.setFont(new java.awt.Font("Dubai Medium", 1, 24)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(0, 0, 0));
        jLabel71.setText("BUSCAR PACIENTE");
        PanelMed.add(jLabel71, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 190, 240, 20));

        jLabel72.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel72.setText("jLabel2");
        PanelMed.add(jLabel72, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 140, 150));

        jPanel12.setBackground(new java.awt.Color(255, 247, 247));
        jPanel12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 4));

        Nombre2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Nombre2.setForeground(new java.awt.Color(0, 0, 0));
        Nombre2.setText("Nombre:");

        jLabel73.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SesionLogo .png"))); // NOI18N

        BtnCerrarSesion1.setBackground(new java.awt.Color(255, 0, 0));
        BtnCerrarSesion1.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        BtnCerrarSesion1.setText("Cerrar Sesion");
        BtnCerrarSesion1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnCerrarSesion1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnCerrarSesion1MouseClicked(evt);
            }
        });
        BtnCerrarSesion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCerrarSesion1ActionPerformed(evt);
            }
        });

        Cargo2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Cargo2.setForeground(new java.awt.Color(0, 0, 0));
        Cargo2.setText("Cargo:");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Nombre2)
                            .addComponent(Cargo2)))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel73, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(37, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(BtnCerrarSesion1)
                .addGap(29, 29, 29))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel73, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Nombre2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Cargo2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BtnCerrarSesion1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelMed.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 20, 180, -1));

        jLabel74.setForeground(new java.awt.Color(102, 255, 204));
        jLabel74.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        PanelMed.add(jLabel74, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(PanelMed, "card10");

        PanelPersonalAdmini.setBackground(new java.awt.Color(0, 153, 153));
        PanelPersonalAdmini.setForeground(new java.awt.Color(255, 255, 255));
        PanelPersonalAdmini.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel15.setBackground(new java.awt.Color(0, 204, 204));
        jPanel15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        jLabel88.setBackground(new java.awt.Color(255, 255, 255));
        jLabel88.setFont(new java.awt.Font("Stencil", 3, 36)); // NOI18N
        jLabel88.setForeground(new java.awt.Color(4, 3, 3));
        jLabel88.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel88.setText("PANEL ADMINISTRAtivo");

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(jLabel88, javax.swing.GroupLayout.PREFERRED_SIZE, 495, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel88, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        PanelPersonalAdmini.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 80, 590, 60));

        BtnPaciente2.setBackground(new java.awt.Color(0, 153, 153));
        BtnPaciente2.setForeground(new java.awt.Color(0, 0, 0));
        BtnPaciente2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/PacienteGrande.png"))); // NOI18N
        BtnPaciente2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnPaciente2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnPaciente2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnPaciente2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnPaciente2MousePressed(evt);
            }
        });
        BtnPaciente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnPaciente2ActionPerformed(evt);
            }
        });
        PanelPersonalAdmini.add(BtnPaciente2, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 330, 350));

        BtnBuscar1.setBackground(new java.awt.Color(0, 153, 153));
        BtnBuscar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/BuscarPaciente.png"))); // NOI18N
        BtnBuscar1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 4, true));
        BtnBuscar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnBuscar1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                BtnBuscar1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                BtnBuscar1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BtnBuscar1MousePressed(evt);
            }
        });
        BtnBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscar1ActionPerformed(evt);
            }
        });
        PanelPersonalAdmini.add(BtnBuscar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 220, 350, 350));

        jLabel89.setFont(new java.awt.Font("Dubai Medium", 1, 24)); // NOI18N
        jLabel89.setForeground(new java.awt.Color(0, 0, 0));
        jLabel89.setText("AGREGAR  PACIENTE");
        PanelPersonalAdmini.add(jLabel89, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 240, 20));

        jLabel90.setFont(new java.awt.Font("Dubai Medium", 1, 24)); // NOI18N
        jLabel90.setForeground(new java.awt.Color(0, 0, 0));
        jLabel90.setText("BUSCAR PACIENTE");
        PanelPersonalAdmini.add(jLabel90, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 190, 240, 20));

        jLabel91.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel91.setText("jLabel2");
        PanelPersonalAdmini.add(jLabel91, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 140, 150));

        jPanel16.setBackground(new java.awt.Color(255, 247, 247));
        jPanel16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 4));

        BtnCerrarSesion2.setBackground(new java.awt.Color(255, 0, 0));
        BtnCerrarSesion2.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        BtnCerrarSesion2.setText("Cerrar Sesion");
        BtnCerrarSesion2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnCerrarSesion2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnCerrarSesion2MouseClicked(evt);
            }
        });
        BtnCerrarSesion2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnCerrarSesion2ActionPerformed(evt);
            }
        });

        Nombre3.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Nombre3.setForeground(new java.awt.Color(0, 0, 0));
        Nombre3.setText("Nombre:");

        jLabel92.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/SesionLogo .png"))); // NOI18N

        Cargo3.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Cargo3.setForeground(new java.awt.Color(0, 0, 0));
        Cargo3.setText("Cargo:");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Nombre3)
                .addGap(136, 136, 136))
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(BtnCerrarSesion2)
                    .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(Cargo3))
                        .addGroup(jPanel16Layout.createSequentialGroup()
                            .addGap(49, 49, 49)
                            .addComponent(jLabel92, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel92, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Nombre3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Cargo3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BtnCerrarSesion2)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        PanelPersonalAdmini.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 20, 190, 220));

        jLabel93.setForeground(new java.awt.Color(102, 255, 204));
        jLabel93.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        PanelPersonalAdmini.add(jLabel93, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(PanelPersonalAdmini, "card12");

        AggPac1.setBackground(new java.awt.Color(0, 153, 153));
        AggPac1.setForeground(new java.awt.Color(255, 255, 255));
        AggPac1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel38.setText("jLabel2");
        AggPac1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 140, 150));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        textField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField11ActionPerformed(evt);
            }
        });
        textField11.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField11KeyPressed(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(0, 0, 0));
        jLabel39.setText("NOMBRE:");

        jLabel40.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(0, 0, 0));
        jLabel40.setText("GENERO:");

        jLabel41.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(0, 0, 0));
        jLabel41.setText("CORREO :");

        jLabel42.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(0, 0, 0));
        jLabel42.setText("APELLIDO:");

        jLabel43.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(0, 0, 0));
        jLabel43.setText("EDAD:");

        jLabel44.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(0, 0, 0));
        jLabel44.setText("TELEFONO:");

        textField12.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField12KeyPressed(evt);
            }
        });

        textField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField13ActionPerformed(evt);
            }
        });
        textField13.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField13KeyPressed(evt);
            }
        });

        textField15.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField15KeyPressed(evt);
            }
        });

        SelecGenero2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));
        SelecGenero2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelecGenero2ActionPerformed(evt);
            }
        });

        PasarHa.setBackground(new java.awt.Color(0, 153, 153));
        PasarHa.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        PasarHa.setForeground(new java.awt.Color(0, 0, 0));
        PasarHa.setText("PASAR A LA HABITACIÓN");
        PasarHa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasarHaActionPerformed(evt);
            }
        });

        jLabel45.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(0, 0, 0));
        jLabel45.setText("EPS:");

        jRadioButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton5ActionPerformed(evt);
            }
        });

        jRadioButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton6ActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(0, 0, 0));
        jLabel46.setText("T.I");

        jLabel47.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(0, 0, 0));
        jLabel47.setText("C.C");

        textField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField16ActionPerformed(evt);
            }
        });
        textField16.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField16KeyPressed(evt);
            }
        });

        Agregar2.setBackground(new java.awt.Color(0, 153, 153));
        Agregar2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Agregar2.setForeground(new java.awt.Color(0, 0, 0));
        Agregar2.setText("AGREGAR");
        Agregar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Agregar2ActionPerformed(evt);
            }
        });

        SelecEps.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "NUEVA EPS", "SANITAS", "SEGURAS", "PARTICULAR", "ASMET SALUD" }));
        SelecEps.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelecEpsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(Agregar2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(PasarHa, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textField11, javax.swing.GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)
                            .addComponent(textField12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SelecGenero2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField13, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(13, 13, 13)
                                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(14, 14, 14)
                                        .addComponent(SelecEps, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(133, 133, 133)
                                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(textField15, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(textField14, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel6Layout.createSequentialGroup()
                                            .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jRadioButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel43, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jRadioButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(8, 8, 8)
                                    .addComponent(textField16, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel42, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(45, 45, 45))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel39))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel42))
                    .addComponent(textField12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelecGenero2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel40))
                .addGap(21, 21, 21)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel43)
                    .addComponent(textField13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel47, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel46, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel44)
                    .addComponent(textField15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel41, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(textField14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelecEps, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel45))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Agregar2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PasarHa, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22))
        );

        AggPac1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 470, 420));

        Tabla3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "APELLIDO", "EDAD", "GENERO", "EPS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Tabla3.setDoubleBuffered(true);
        Tabla3.setUpdateSelectionOnSort(false);
        Tabla3.setVerifyInputWhenFocusTarget(false);
        jScrollPane3.setViewportView(Tabla3);

        AggPac1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 520, 490));

        jLabel48.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Paciente.png"))); // NOI18N
        AggPac1.add(jLabel48, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 10, -1, 150));

        Regresar4.setBackground(new java.awt.Color(0, 0, 0));
        Regresar4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar4.setForeground(new java.awt.Color(255, 255, 255));
        Regresar4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar4.setText("Regresar");
        Regresar4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar4ActionPerformed(evt);
            }
        });
        AggPac1.add(Regresar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel49.setFont(new java.awt.Font("Stencil", 0, 48)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 102, 0));
        jLabel49.setText("MENÚ PACIENTE");
        AggPac1.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 40, -1, 70));

        Automatizado.setText("AUTOMATICO");
        Automatizado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AutomatizadoActionPerformed(evt);
            }
        });
        AggPac1.add(Automatizado, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 570, -1, 40));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 520, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 490, Short.MAX_VALUE)
        );

        AggPac1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 520, 490));

        jLabel50.setForeground(new java.awt.Color(102, 255, 204));
        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        AggPac1.add(jLabel50, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(AggPac1, "card7");

        AggPac2.setBackground(new java.awt.Color(0, 153, 153));
        AggPac2.setForeground(new java.awt.Color(255, 255, 255));
        AggPac2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel51.setText("jLabel2");
        AggPac2.add(jLabel51, new org.netbeans.lib.awtextra.AbsoluteConstraints(1160, -40, 140, 150));

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));

        jLabel52.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(0, 0, 0));
        jLabel52.setText("NOMBRE:");

        jLabel53.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel53.setForeground(new java.awt.Color(0, 0, 0));
        jLabel53.setText("GENERO:");

        jLabel54.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(0, 0, 0));
        jLabel54.setText("PESO:");

        jLabel55.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(0, 0, 0));
        jLabel55.setText("APELLIDO:");

        jLabel56.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(0, 0, 0));
        jLabel56.setText("EDAD:");

        jLabel57.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(0, 0, 0));
        jLabel57.setText("ESTATURA:");

        SelecGenero4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO", " " }));

        GUARDAR.setBackground(new java.awt.Color(0, 204, 204));
        GUARDAR.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        GUARDAR.setForeground(new java.awt.Color(0, 0, 0));
        GUARDAR.setText("GUARDAR");
        GUARDAR.setActionCommand("PASAR A MEDICO");
        GUARDAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        GUARDAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GUARDARActionPerformed(evt);
            }
        });

        jLabel58.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(0, 0, 0));
        jLabel58.setText("OBSERVACIONES:");

        jLabel59.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(0, 0, 0));
        jLabel59.setText("ID");

        jLabel60.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(0, 0, 0));
        jLabel60.setText("KG");

        ABRIR.setBackground(new java.awt.Color(0, 204, 204));
        ABRIR.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        ABRIR.setForeground(new java.awt.Color(0, 0, 0));
        ABRIR.setText("ABRIR");
        ABRIR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ABRIR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ABRIRActionPerformed(evt);
            }
        });

        jLabel61.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(0, 0, 0));
        jLabel61.setText("TIPO DE SANGRE:");

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "0+", "A+", "B+", "AB", "A-", "B-", "O-" }));

        ELIMINAR.setBackground(new java.awt.Color(0, 204, 204));
        ELIMINAR.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        ELIMINAR.setForeground(new java.awt.Color(0, 0, 0));
        ELIMINAR.setText("ELIMINAR");
        ELIMINAR.setActionCommand("PASAR A MEDICO");
        ELIMINAR.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ELIMINAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ELIMINARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel54)
                                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel52, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel55, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(69, 69, 69))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel53, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textField17, javax.swing.GroupLayout.DEFAULT_SIZE, 318, Short.MAX_VALUE)
                            .addComponent(textField18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(SelecGenero4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(textField19, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textField21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(textField20, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(textField22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(textArea1, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(ABRIR, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ELIMINAR)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                        .addComponent(GUARDAR)
                        .addGap(67, 67, 67)))
                .addGap(45, 45, 45))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel52))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel55))
                    .addComponent(textField18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SelecGenero4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel53, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel56)
                    .addComponent(textField19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel61)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel59, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel57)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel54))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(textField21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(textField20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel60, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textArea1, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel58))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(GUARDAR, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(ABRIR, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1, 1, 1)))
                        .addGap(50, 50, 50))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(ELIMINAR, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))))
        );

        AggPac2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 160, 500, 500));

        jLabel62.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Paciente.png"))); // NOI18N
        AggPac2.add(jLabel62, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 0, 130, 130));

        Regresar5.setBackground(new java.awt.Color(0, 0, 0));
        Regresar5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar5.setForeground(new java.awt.Color(255, 255, 255));
        Regresar5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar5.setText("Regresar");
        Regresar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar5ActionPerformed(evt);
            }
        });
        AggPac2.add(Regresar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        jLabel63.setFont(new java.awt.Font("Stencil", 0, 48)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(255, 102, 0));
        jLabel63.setText("MENÚ PACIENTE DEL MÉDICO");
        AggPac2.add(jLabel63, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 30, -1, 70));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));

        Tabla5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "APELLIDO", "EDAD", "GENERO"
            }
        ));
        jScrollPane5.setViewportView(Tabla5);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        AggPac2.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 510, 490));

        jLabel65.setFont(new java.awt.Font("Dubai Medium", 1, 24)); // NOI18N
        jLabel65.setForeground(new java.awt.Color(0, 0, 0));
        jLabel65.setText("PROCESOS DE ENTRADA");
        AggPac2.add(jLabel65, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 130, 280, 20));

        jLabel66.setForeground(new java.awt.Color(102, 255, 204));
        jLabel66.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        AggPac2.add(jLabel66, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(AggPac2, "card8");

        AggPac3.setBackground(new java.awt.Color(0, 153, 153));
        AggPac3.setForeground(new java.awt.Color(255, 255, 255));
        AggPac3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel75.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel75.setText("jLabel2");
        AggPac3.add(jLabel75, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 510, 140, 150));

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        textField23.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField23KeyPressed(evt);
            }
        });

        jLabel76.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(0, 0, 0));
        jLabel76.setText("NOMBRE:");

        jLabel77.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(0, 0, 0));
        jLabel77.setText("GENERO:");

        jLabel78.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(0, 0, 0));
        jLabel78.setText("CORREO :");

        jLabel79.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(0, 0, 0));
        jLabel79.setText("APELLIDO:");

        jLabel80.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(0, 0, 0));
        jLabel80.setText("EDAD:");

        jLabel81.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel81.setForeground(new java.awt.Color(0, 0, 0));
        jLabel81.setText("TELEFONO:");

        textField24.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField24KeyPressed(evt);
            }
        });

        textField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField25ActionPerformed(evt);
            }
        });
        textField25.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField25KeyPressed(evt);
            }
        });

        textField27.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField27KeyPressed(evt);
            }
        });

        SelecGenero3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));
        SelecGenero3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelecGenero3ActionPerformed(evt);
            }
        });

        PasarHab2.setBackground(new java.awt.Color(0, 153, 153));
        PasarHab2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        PasarHab2.setForeground(new java.awt.Color(0, 0, 0));
        PasarHab2.setText("PASAR A LA HABITACIÓN");
        PasarHab2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PasarHab2ActionPerformed(evt);
            }
        });

        jLabel82.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel82.setForeground(new java.awt.Color(0, 0, 0));
        jLabel82.setText("EPS:");

        jRadioButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton7ActionPerformed(evt);
            }
        });

        jRadioButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton8ActionPerformed(evt);
            }
        });

        jLabel83.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel83.setForeground(new java.awt.Color(0, 0, 0));
        jLabel83.setText("T.I");

        jLabel84.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel84.setForeground(new java.awt.Color(0, 0, 0));
        jLabel84.setText("C.C");

        textField28.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField28KeyPressed(evt);
            }
        });

        Agregar5.setBackground(new java.awt.Color(0, 153, 153));
        Agregar5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Agregar5.setForeground(new java.awt.Color(0, 0, 0));
        Agregar5.setText("AGREGAR");
        Agregar5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Agregar5ActionPerformed(evt);
            }
        });

        SelecEps1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "NUEVA EPS", "SANITAS", "SEGURAS", "PARTICULAR", "ASMET SALUD" }));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel78)
                            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel76, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel80, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel79, javax.swing.GroupLayout.Alignment.LEADING)))
                        .addGap(69, 69, 69))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel77, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel81, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(textField23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(textField24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(SelecGenero3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField25, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField26, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField27, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jRadioButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textField28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(45, 45, 45))
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addComponent(jLabel83, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(jRadioButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel84, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(360, 360, 360))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel13Layout.createSequentialGroup()
                                .addComponent(jLabel82, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(SelecEps1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel13Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(Agregar5, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(PasarHab2)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel76))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel79))
                    .addComponent(textField24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SelecGenero3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel77, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel80)
                    .addComponent(textField25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel84, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField28, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel83, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel81)
                    .addComponent(textField27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField26, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel78, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SelecEps1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel82))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Agregar5, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PasarHab2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );

        AggPac3.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 470, 430));

        jLabel85.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Paciente.png"))); // NOI18N
        AggPac3.add(jLabel85, new org.netbeans.lib.awtextra.AbsoluteConstraints(1130, 10, -1, 150));

        Regresar7.setBackground(new java.awt.Color(0, 0, 0));
        Regresar7.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar7.setForeground(new java.awt.Color(255, 255, 255));
        Regresar7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar7.setText("Regresar");
        Regresar7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar7ActionPerformed(evt);
            }
        });
        AggPac3.add(Regresar7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel86.setFont(new java.awt.Font("Stencil", 0, 48)); // NOI18N
        jLabel86.setForeground(new java.awt.Color(255, 102, 0));
        jLabel86.setText("MENÚ PACIENTE DEL ADMINISTRATIVO");
        AggPac3.add(jLabel86, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 40, -1, 70));

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));

        Tabla6.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "APELLIDO", "EDAD", "GENERO", "EPS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Tabla6.setRequestFocusEnabled(false);
        jScrollPane6.setViewportView(Tabla6);

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 530, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 490, Short.MAX_VALUE)
        );

        AggPac3.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 140, 530, 490));

        jLabel87.setForeground(new java.awt.Color(102, 255, 204));
        jLabel87.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        AggPac3.add(jLabel87, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(AggPac3, "card11");

        AggPersonalAdmini.setBackground(new java.awt.Color(0, 153, 153));
        AggPersonalAdmini.setForeground(new java.awt.Color(255, 255, 255));
        AggPersonalAdmini.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel24.setText("jLabel2");
        AggPersonalAdmini.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 520, 140, 150));

        Regresar2.setBackground(new java.awt.Color(0, 0, 0));
        Regresar2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar2.setForeground(new java.awt.Color(255, 255, 255));
        Regresar2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar2.setText("Regresar");
        Regresar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar2ActionPerformed(evt);
            }
        });
        AggPersonalAdmini.add(Regresar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        textField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField4ActionPerformed(evt);
            }
        });
        textField4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField4KeyPressed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 0, 0));
        jLabel25.setText("NOMBRE:");

        jLabel26.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 0, 0));
        jLabel26.setText("GENERO:");

        jLabel27.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 0, 0));
        jLabel27.setText("APELLIDO:");

        jLabel28.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 0, 0));
        jLabel28.setText("EDAD:");

        jLabel29.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 0, 0));
        jLabel29.setText("TELEFONO:");

        textField7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField7KeyPressed(evt);
            }
        });

        textField8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField8KeyPressed(evt);
            }
        });

        textField9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField9KeyPressed(evt);
            }
        });

        SelecGenero1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));
        SelecGenero1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelecGenero1ActionPerformed(evt);
            }
        });

        jLabel30.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(0, 0, 0));
        jLabel30.setText("CARGO:");

        jRadioButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton3ActionPerformed(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 0, 0));
        jLabel31.setText("C.C");

        textField10.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField10KeyPressed(evt);
            }
        });

        Agregar1.setBackground(new java.awt.Color(0, 153, 153));
        Agregar1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Agregar1.setForeground(new java.awt.Color(0, 0, 0));
        Agregar1.setText("AGREGAR");
        Agregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Agregar1ActionPerformed(evt);
            }
        });

        SelecCargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "SECRETARI@", "RECEPCIONISTA", "ASISTENTE" }));

        Eliminar1.setBackground(new java.awt.Color(0, 153, 153));
        Eliminar1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Eliminar1.setForeground(new java.awt.Color(0, 0, 0));
        Eliminar1.setText("ELIMINAR");
        Eliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Eliminar1ActionPerformed(evt);
            }
        });

        jLabel98.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel98.setForeground(new java.awt.Color(0, 0, 0));
        jLabel98.setText("USUARIO:");

        jLabel99.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel99.setForeground(new java.awt.Color(0, 0, 0));
        jLabel99.setText("CONTRASEÑA:");

        textField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField31ActionPerformed(evt);
            }
        });

        textField32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField32ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(Agregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71)
                .addComponent(Eliminar1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(69, 69, 69))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jRadioButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel29, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(textField4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(textField7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(SelecGenero1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField8, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(textField9, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(textField10, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel98, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel99, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField32, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField31, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SelecCargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(textField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel25))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel27))
                            .addComponent(textField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(SelecGenero1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jRadioButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel31, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(textField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel29))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel30)
                            .addComponent(SelecCargo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel98))
                    .addComponent(textField31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel99, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Agregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Eliminar1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(104, 104, 104))
        );

        AggPersonalAdmini.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 480, 430));

        Tabla2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "APELLIDO", "EDAD", "GENERO", "CARGO"
            }
        ));
        jScrollPane2.setViewportView(Tabla2);

        AggPersonalAdmini.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 130, 550, 490));

        jLabel33.setFont(new java.awt.Font("Stencil", 0, 48)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 102, 0));
        jLabel33.setText("MENÚ PERSONAL ADMINISTRATIVO");
        AggPersonalAdmini.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, -1, 70));

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/PersonalAdmin.png"))); // NOI18N
        AggPersonalAdmini.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 10, -1, -1));

        jLabel35.setForeground(new java.awt.Color(102, 255, 204));
        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        AggPersonalAdmini.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(AggPersonalAdmini, "card5");

        AggPersonalMed.setBackground(new java.awt.Color(0, 153, 153));
        AggPersonalMed.setForeground(new java.awt.Color(255, 255, 255));
        AggPersonalMed.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel12.setText("jLabel2");
        AggPersonalMed.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 140, 150));

        Regresar1.setBackground(new java.awt.Color(0, 0, 0));
        Regresar1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar1.setForeground(new java.awt.Color(255, 255, 255));
        Regresar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar1.setText("Regresar");
        Regresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar1ActionPerformed(evt);
            }
        });
        AggPersonalMed.add(Regresar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        textField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField1KeyPressed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("NOMBRE:");

        jLabel14.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("GENERO:");

        jLabel15.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("APELLIDO:");

        jLabel16.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("EDAD:");

        jLabel17.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("TELEFONO:");

        textField2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField2KeyPressed(evt);
            }
        });

        textField3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField3KeyPressed(evt);
            }
        });

        textField5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField5KeyPressed(evt);
            }
        });

        SelecGenero.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));
        SelecGenero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelecGeneroActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("  USUARIO:");

        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("C.C");

        textField6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                textField6KeyPressed(evt);
            }
        });

        Agregar.setBackground(new java.awt.Color(0, 153, 153));
        Agregar.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Agregar.setForeground(new java.awt.Color(0, 0, 0));
        Agregar.setText("AGREGAR");
        Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarActionPerformed(evt);
            }
        });

        SelecEspe.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "CIRUJAN@", "ENFERMER@", "MEDICO ", "TERAPEUTA", "ODONTOLOG@" }));

        Eliminar.setBackground(new java.awt.Color(0, 153, 153));
        Eliminar.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Eliminar.setForeground(new java.awt.Color(0, 0, 0));
        Eliminar.setText("ELIMINAR");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });

        textField29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField29ActionPerformed(evt);
            }
        });

        textField30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                textField30ActionPerformed(evt);
            }
        });

        jLabel96.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel96.setForeground(new java.awt.Color(0, 0, 0));
        jLabel96.setText("  ESPECIALIDAD:");

        jLabel97.setFont(new java.awt.Font("Segoe UI Emoji", 3, 14)); // NOI18N
        jLabel97.setForeground(new java.awt.Color(0, 0, 0));
        jLabel97.setText("CONTRASEÑA:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(46, 46, 46)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField1, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField2, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SelecGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(62, 62, 62)
                                        .addComponent(jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel97, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel96, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(10, 10, 10)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textField6, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SelecEspe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField5, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField29, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textField30, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(Agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(63, 63, 63)
                        .addComponent(Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel15)
                        .addGap(2, 2, 2))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(textField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SelecGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel16)
                    .addComponent(textField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(textField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jRadioButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel17)
                        .addGap(4, 4, 4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(textField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel96, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SelecEspe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(textField29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(textField30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jLabel97, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(66, 66, 66))
        );

        AggPersonalMed.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 130, 470, 420));

        Tabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "APELLIDO", "EDAD", "GENERO", "ESPECIALIDAD"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla1);
        Tabla1.getAccessibleContext().setAccessibleName("");
        Tabla1.getAccessibleContext().setAccessibleDescription("");

        AggPersonalMed.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 560, 490));

        Automatico.setText("AUTOMATIZADO");
        Automatico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AutomaticoActionPerformed(evt);
            }
        });
        AggPersonalMed.add(Automatico, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 580, 130, 40));

        jLabel21.setFont(new java.awt.Font("Stencil", 0, 48)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 102, 0));
        jLabel21.setText("MENÚ PERSONAL MÉDICO");
        AggPersonalMed.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 40, -1, 70));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Medico.png"))); // NOI18N
        AggPersonalMed.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 10, -1, 160));

        jLabel23.setForeground(new java.awt.Color(102, 255, 204));
        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        AggPersonalMed.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(AggPersonalMed, "card4");

        InhHab.setBackground(new java.awt.Color(0, 153, 153));
        InhHab.setForeground(new java.awt.Color(255, 255, 255));
        InhHab.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/piso1 .png"))); // NOI18N
        InhHab.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 140, 170));

        Regresar.setBackground(new java.awt.Color(0, 0, 0));
        Regresar.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar.setText("Regresar");
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        InhHab.add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel114.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/piso3.png"))); // NOI18N
        InhHab.add(jLabel114, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 480, 140, 170));

        jLabel113.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/piso2 .png"))); // NOI18N
        InhHab.add(jLabel113, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 300, 140, 170));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel10.setText("jLabel2");
        InhHab.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 140, -1));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));

        jPanel19.setBackground(new java.awt.Color(0, 102, 102));

        jLabel20.setBackground(new java.awt.Color(255, 255, 255));
        jLabel20.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("HABITACIONES DE LA CLINICA");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jLabel20)
                .addGap(0, 4, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(7, Short.MAX_VALUE))
        );

        InhHab.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 60, -1, 50));

        jPanel17.setBackground(new java.awt.Color(0, 102, 102));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        HabitacionesCompletas.setBackground(new java.awt.Color(0, 0, 0));
        HabitacionesCompletas.setLayout(new java.awt.GridLayout(3, 4, 10, 10));

        pHabitacionJPanel.setLayout(new java.awt.GridLayout(0, 1, 0, 2));
        HabitacionesCompletas.add(pHabitacionJPanel);

        jPanel17.add(HabitacionesCompletas, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 1010, 550));

        InhHab.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 90, 1060, 580));

        jLabel11.setForeground(new java.awt.Color(102, 255, 204));
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        InhHab.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(InhHab, "card3");

        BuscarPac2.setBackground(new java.awt.Color(0, 153, 153));
        BuscarPac2.setForeground(new java.awt.Color(255, 255, 255));
        BuscarPac2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel20.setBackground(new java.awt.Color(0, 102, 102));

        jPanel21.setBackground(new java.awt.Color(0, 0, 0));

        jLabel115.setFont(new java.awt.Font("Segoe UI Black", 1, 36)); // NOI18N
        jLabel115.setForeground(new java.awt.Color(255, 255, 255));
        jLabel115.setText("BUSCAR PACIENTES");

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel21Layout.createSequentialGroup()
                .addContainerGap(147, Short.MAX_VALUE)
                .addComponent(jLabel115)
                .addGap(156, 156, 156))
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel21Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel115))
        );

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(8, Short.MAX_VALUE))
        );

        BuscarPac2.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 40, 690, 70));

        jPanel18.setBackground(new java.awt.Color(0, 102, 102));

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));

        jLabel116.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        jLabel116.setForeground(new java.awt.Color(0, 0, 0));
        jLabel116.setText("Paciente:");

        buscarID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarIDActionPerformed(evt);
            }
        });
        buscarID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                buscarIDKeyTyped(evt);
            }
        });

        jPanel23.setLayout(new java.awt.CardLayout());

        Buscar.setText("BUSCAR");
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "NOMBRE", "APELLIDO", "EDAD", "GÉNERO", " TELEFONO", "OBSERVACIÓN", "HABITACIÓN", "CAMILLA"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane8.setViewportView(jTable2);

        jButton2.setText("MODIFICAR");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel117.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel117.setForeground(new java.awt.Color(0, 0, 0));
        jLabel117.setText("SELECCIONA EL PACIENTE PARA MODIFICAR");

        jLabel118.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel118.setForeground(new java.awt.Color(0, 0, 0));
        jLabel118.setText("NOMBRE:");

        jLabel119.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel119.setForeground(new java.awt.Color(0, 0, 0));
        jLabel119.setText("APELLIDO:");

        jLabel120.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel120.setForeground(new java.awt.Color(0, 0, 0));
        jLabel120.setText("ID:");

        jLabel121.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel121.setForeground(new java.awt.Color(0, 0, 0));
        jLabel121.setText("TELEFONO:");

        jLabel122.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel122.setForeground(new java.awt.Color(0, 0, 0));
        jLabel122.setText("EDAD:");

        jLabel123.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel123.setForeground(new java.awt.Color(0, 0, 0));
        jLabel123.setText("CORREO:");

        jLabel124.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel124.setForeground(new java.awt.Color(0, 0, 0));
        jLabel124.setText("ESTATURA:");

        jLabel125.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel125.setForeground(new java.awt.Color(0, 0, 0));
        jLabel125.setText("GÉNERO:");

        jLabel126.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel126.setForeground(new java.awt.Color(0, 0, 0));
        jLabel126.setText("EPS:");

        jLabel127.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel127.setForeground(new java.awt.Color(0, 0, 0));
        jLabel127.setText("PESO:");

        jLabel128.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel128.setForeground(new java.awt.Color(0, 0, 0));
        jLabel128.setText("KG");

        jLabel129.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel129.setForeground(new java.awt.Color(0, 0, 0));
        jLabel129.setText("SANGRE:");

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "MASCULINO", "FEMENINO" }));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "NUEVA EPS", "SANITAS", "SEGURAS", "PARTICULAR", "ASMET SALUD" }));

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECCIONAR", "0+", "A+", "B+", "AB", "A-", "B-", "0-" }));

        jLabel130.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel130.setForeground(new java.awt.Color(0, 0, 0));
        jLabel130.setText("OBSERVACIÓN:");

        jButton4.setText("GUARDAR");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane7.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(88, 88, 88)
                                .addComponent(jLabel116)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(buscarID, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(306, 306, 306)
                                .addComponent(jLabel117))
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(91, 91, 91)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel22Layout.createSequentialGroup()
                                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jLabel118, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel119, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel120, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                                            .addComponent(jTextField4)
                                            .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.TRAILING)))
                                    .addGroup(jPanel22Layout.createSequentialGroup()
                                        .addComponent(jLabel121, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel22Layout.createSequentialGroup()
                                        .addComponent(jLabel123, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel127, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(16, 16, 16)
                                        .addComponent(jLabel128))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel22Layout.createSequentialGroup()
                                                .addComponent(jLabel122, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jLabel124, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jTextField8))
                                            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel22Layout.createSequentialGroup()
                                                    .addComponent(jLabel125, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jLabel129, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel22Layout.createSequentialGroup()
                                                    .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(jPanel22Layout.createSequentialGroup()
                                                            .addComponent(jLabel126, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                            .addGap(18, 18, 18)
                                                            .addComponent(jLabel130))
                                                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(0, 22, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane8)))
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel116)
                    .addComponent(buscarID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Buscar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel117)
                .addGap(14, 14, 14)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel118)
                    .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel122)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel124)
                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel119)
                                .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel123)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel120)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel125)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel121)
                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel126)
                                .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(42, 42, 42)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel22Layout.createSequentialGroup()
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel127)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(3, 3, 3))
                            .addComponent(jLabel128, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43))
                            .addGroup(jPanel22Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel129)
                                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel130)
                                    .addComponent(jScrollPane7))))))
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        BuscarPac2.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 80, 980, 590));

        jLabel94.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoHospital.png"))); // NOI18N
        jLabel94.setText("jLabel2");
        BuscarPac2.add(jLabel94, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 520, 140, 150));

        Regresar8.setBackground(new java.awt.Color(0, 0, 0));
        Regresar8.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        Regresar8.setForeground(new java.awt.Color(255, 255, 255));
        Regresar8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/LogoRegresar (1).png"))); // NOI18N
        Regresar8.setText("Regresar");
        Regresar8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar8ActionPerformed(evt);
            }
        });
        BuscarPac2.add(Regresar8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel95.setForeground(new java.awt.Color(102, 255, 204));
        jLabel95.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        BuscarPac2.add(jLabel95, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -4, 1310, 690));

        Padre.add(BuscarPac2, "card9");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Padre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Padre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BtnInhabilitarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInhabilitarMouseEntered
        BtnInhabilitar.setBackground(Color.LIGHT_GRAY); // TODO add your handling code here:
    }//GEN-LAST:event_BtnInhabilitarMouseEntered

    private void BtnInhabilitarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInhabilitarMouseExited
        BtnInhabilitar.setBackground(new Color(0, 153, 153)); // TODO add your handling code here:
    }//GEN-LAST:event_BtnInhabilitarMouseExited

    private void BtnInhabilitarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInhabilitarActionPerformed
        Padre.removeAll();
        Padre.add(InhHab);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);
        llenarcamillas();
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnInhabilitarActionPerformed

    private void BtnPacienteMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPacienteMouseEntered
        BtnPaciente.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_BtnPacienteMouseEntered

    private void BtnPacienteMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPacienteMouseExited
        BtnPaciente.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnPacienteMouseExited

    private void BtnPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnPacienteActionPerformed
        Padre.removeAll();
        Padre.add(AggPac1);
        Padre.repaint();
        Padre.revalidate();

        this.setVisible(true);

    }//GEN-LAST:event_BtnPacienteActionPerformed

    private void BtnCamillaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCamillaMouseEntered
        BtnCamilla.setBackground(Color.LIGHT_GRAY);// TODO add your handling code here:
    }//GEN-LAST:event_BtnCamillaMouseEntered

    private void BtnCamillaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCamillaMouseExited
        BtnCamilla.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnCamillaMouseExited

    private void BtnCamillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCamillaActionPerformed
        Padre.removeAll();
        Padre.add(BuscarPac2);
        if (jTextField5.getText().isBlank()) {
            jTextField5.setEnabled(false);
            jTextField4.setEnabled(false);
            jTextField3.setEnabled(false);
            jTextField1.setEnabled(false);
            jTextField6.setEnabled(false);
            jTextField7.setEnabled(false);
            jTextField8.setEnabled(false);
            jTextField9.setEnabled(false);
            jTextArea1.setEnabled(false);
            jComboBox2.setEnabled(false);
            jComboBox3.setEnabled(false);
            jComboBox4.setEnabled(false);
        }
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_BtnCamillaActionPerformed

    private void BtnDoctorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnDoctorMouseEntered
        BtnDoctor.setBackground(Color.LIGHT_GRAY);// TODO add your handling code here:
    }//GEN-LAST:event_BtnDoctorMouseEntered

    private void BtnDoctorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnDoctorMouseExited
        BtnDoctor.setBackground(new Color(0, 153, 153));   // TODO add your handling code here:
    }//GEN-LAST:event_BtnDoctorMouseExited

    private void BtnDoctorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnDoctorActionPerformed
        Padre.removeAll();
        Padre.add(AggPersonalMed);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_BtnDoctorActionPerformed

    private void BtnPersonalAdminMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPersonalAdminMouseEntered
        BtnPersonalAdmin.setBackground(Color.LIGHT_GRAY);// TODO add your handling code here:
    }//GEN-LAST:event_BtnPersonalAdminMouseEntered

    private void BtnPersonalAdminMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPersonalAdminMouseExited
        BtnPersonalAdmin.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnPersonalAdminMouseExited

    private void BtnPersonalAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnPersonalAdminActionPerformed
        Padre.removeAll();
        Padre.add(AggPersonalAdmini);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_BtnPersonalAdminActionPerformed

    private void BtnCerrarSesionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCerrarSesionMouseClicked
        cerrarSesion();
    }//GEN-LAST:event_BtnCerrarSesionMouseClicked

    private void BtnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCerrarSesionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnCerrarSesionActionPerformed

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        Padre.removeAll();
        Padre.add(PanelAdmin);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_RegresarActionPerformed

    private void Regresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar1ActionPerformed
        Padre.removeAll();
        Padre.add(PanelAdmin);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_Regresar1ActionPerformed

    private void SelecGeneroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelecGeneroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelecGeneroActionPerformed

    private void AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarActionPerformed
        String id = textField6.getText();
        String nombre = textField1.getText();
        String apellido = textField2.getText();
        String edad = textField3.getText();
        String telefono = textField5.getText();
        String genero = (String) (SelecGenero.getSelectedItem());
        String espe = (String) (SelecEspe.getSelectedItem());
        String usuario = textField29.getText();
        String contrasena = textField30.getText();
        String Datos[] = {id, nombre, apellido, edad, genero, espe};
        boolean g = (genero.equalsIgnoreCase("masculino") ? true : false);

        if (ConfirmacionPersonalMed().equals("")) {
            PersonalMedico emp = new PersonalMedico(espe, usuario, Integer.parseInt(id), contrasena, nombre, apellido, g, Integer.parseInt(edad), Integer.parseInt(id), Long.parseLong(telefono));
            if (Hospital.getEmpleados().registrarEmpleado(emp) == false) {
                JOptionPane.showMessageDialog(null, "El Nombre de Usuario ya esta en Uso");

            } else {

                if (!Hospital.IngresarMed(emp)) {
                    JOptionPane.showMessageDialog(null, "No se puede agregar medico, habitacion deshabilitada");
                } else {
                    JOptionPane.showMessageDialog(null, "Añadido con Exito");
                    llenarTabla(Tabla1, Datos);
                }
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField5.setText("");
                textField6.setText("");
                textField29.setText("");
                textField30.setText("");
                SelecGenero.setSelectedIndex(0);
                SelecEspe.setSelectedIndex(0);
                jRadioButton1.setSelected(false);
            }
        } else {
            JOptionPane.showMessageDialog(null, ConfirmacionPersonalMed());
        }

    }//GEN-LAST:event_AgregarActionPerformed

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
        eliminarTabla(Tabla1);

    }//GEN-LAST:event_EliminarActionPerformed

    private void Regresar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar2ActionPerformed
        Padre.removeAll();
        Padre.add(PanelAdmin);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_Regresar2ActionPerformed

    private void SelecGenero1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelecGenero1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelecGenero1ActionPerformed

    private void jRadioButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton3ActionPerformed

    }//GEN-LAST:event_jRadioButton3ActionPerformed

    private void Agregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Agregar1ActionPerformed
        // TODO add your handling code here:
        String id = textField10.getText();
        String nombre = textField4.getText();
        String apellido = textField7.getText();
        String genero = (String) (SelecGenero1.getSelectedItem());
        String edad = textField8.getText();
        String espe = (String) (SelecCargo.getSelectedItem());
        String telefono = textField9.getText();
        String usuario = textField31.getText();
        String contraseña = textField32.getText();
        String Datos[] = {id, nombre, apellido, edad, genero, espe};
        boolean g = (genero.equalsIgnoreCase("masculino") ? true : false);

        if (ConfirmacionPersonalAdmini().equals("")) {
            llenarTabla(Tabla2, Datos);
            Personal_Admin emp2 = new Personal_Admin(espe, usuario, Integer.parseInt(id), contraseña, nombre, apellido, g, Integer.parseInt(edad), Integer.parseInt(id), Long.parseLong(telefono));
            Hospital.getEmpleados().registrarEmpleado(emp2);
            textField10.setText("");
            textField4.setText("");
            textField7.setText("");
            textField8.setText("");
            textField9.setText("");
            SelecGenero1.setSelectedIndex(0);
            SelecCargo.setSelectedIndex(0);
            textField31.setText("");
            textField32.setText("");
            jRadioButton3.setSelected(false);
        } else {
            JOptionPane.showMessageDialog(null, ConfirmacionPersonalAdmini());
        }
    }//GEN-LAST:event_Agregar1ActionPerformed

    private void Eliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Eliminar1ActionPerformed
        eliminarTabla(Tabla2);
    }//GEN-LAST:event_Eliminar1ActionPerformed

    private void SelecGenero2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelecGenero2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelecGenero2ActionPerformed

    private void PasarHaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasarHaActionPerformed
        int eli = Tabla3.getSelectedRow();

        if (eli != -1) {
            int id = Integer.parseInt((String) Tabla3.getValueAt(eli, 0));
            if (!Hospital.getPacientes().obtenerPaciente(id).isEnhabitacion()) {
                String[] pisos = {"1", "2", "3"};
                String habitaciones[] = {"01", "02", "03", "04"};
                int piso = JOptionPane.showOptionDialog(null, "Elige un piso:", "Clinica",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, pisos, null);
                piso++;
                while (piso == 0) {
                    piso = JOptionPane.showOptionDialog(null, "Elige un piso:", "Clinica",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, pisos, null);
                    piso++;
                }
                for (int i = 0; i < habitaciones.length; i++) {
                    habitaciones[i] = piso + habitaciones[i];
                }
                int habitacion = JOptionPane.showOptionDialog(null, "Elige una habitación:", "Clinica",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, habitaciones, null);
                habitacion++;
                while (habitacion == 0) {
                    habitacion = JOptionPane.showOptionDialog(null, "Elige una habitación:", "Clinica",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, habitaciones, null);
                    habitacion++;
                }
                if (Hospital.getHabitaciones()[piso - 1][habitacion - 1].getMedico() == null) {
                    JOptionPane.showMessageDialog(null, "El paciente No se puede añadir, No hay Medico que Atienda");
                } else {
                    if (Hospital.getHabitaciones()[piso - 1][habitacion - 1].isEstado()) {
                        Paciente tmp = Hospital.getPacientes().obtenerPaciente(id);
                        String valor = Hospital.getHabitaciones()[piso - 1][habitacion - 1].AnadirP(tmp);
                        if (!valor.equals("No se puede añadir, camillas ocupadas")) {
                            tmp.setEnhabitacion(true);
                            PersonalMedico tmpMed = Hospital.getHabitaciones()[piso - 1][habitacion - 1].getMedico();
                            String medico = tmpMed.getNombre() + "      Especialidad: " + tmpMed.getEspecialidad();
                            String confirmaHab = piso + "0" + habitacion;
                            JOptionPane.showMessageDialog(null, valor + " en la habitacion:" + confirmaHab + "\nUbicado en la Camilla: " + tmp.getHabitacion()[2] + "\n <<<<<<<<<<<<Medico De Atención:>>>>>>>>>>>>\n" + "Nombre: " + medico);
                            tmp.setMedico(tmpMed);
                            tmp.setPieza(confirmaHab);
                            String g = (tmp.getGenero() == true) ? "Masculino" : "Femenino";
                            Object Datos2[] = {tmp.getNumeroIdentidad(), tmp.getNombre(), tmp.getApellido(), tmp.getEdad(), g, tmp.getNumeroTelefono(), "VACIO", confirmaHab, tmp.getHabitacion()[2]};
                            llenarTabla(jTable2, Datos2);

                        } else {
                            JOptionPane.showMessageDialog(null, "No se ha logrado añadir al paciente a la habitacion");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No puede agregar pacientes en una habitacion deshabilitada");

                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "El paciente no se puede añadir ya se encuentra en una habitación");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se puede añadir, no se ha seleccionado ningún paciente");
        }
    }//GEN-LAST:event_PasarHaActionPerformed

    private void jRadioButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton5ActionPerformed
        jRadioButton5.setSelected(true);
        {
            jRadioButton6.setSelected(false);
        }
    }//GEN-LAST:event_jRadioButton5ActionPerformed

    private void jRadioButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton6ActionPerformed
        jRadioButton5.setSelected(false);
        {
            jRadioButton6.setSelected(true);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton6ActionPerformed

    private void Agregar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Agregar2ActionPerformed
        // TODO add your handling code here:
        String id = textField16.getText();
        String nombre = textField11.getText();
        String apellido = textField12.getText();
        String edad = textField13.getText();
        String telefono = textField15.getText();
        String correo = textField14.getText();
        String genero = (String) (SelecGenero2.getSelectedItem());
        String eps = (String) (SelecEps.getSelectedItem());
        boolean g = (genero.equalsIgnoreCase("masculino") ? true : false);
        String Datos[] = {id, nombre, apellido, edad, genero, eps};

        if (ConfirmacionMenuPaciente().equals("")) {
            JOptionPane.showMessageDialog(null, "El paciente Ha Sido Añadido Éxitosamente Al Hospital");
            llenarTabla(Tabla3, Datos);
            llenarTabla(Tabla6, Datos);
            Hospital.getPacientes().registrarPaciente(new Paciente(correo, null, null, eps, true, 0, 0, nombre, apellido, g, Integer.parseInt(edad), Integer.parseInt(id), Long.parseLong(telefono)));
            textField16.setText("");
            textField11.setText("");
            textField12.setText("");
            textField13.setText("");
            textField15.setText("");
            textField14.setText("");
            SelecGenero2.setSelectedIndex(0);
            SelecEps.setSelectedIndex(0);
            jRadioButton5.setSelected(false);
            jRadioButton6.setSelected(false);
        } else {
            JOptionPane.showMessageDialog(null, ConfirmacionMenuPaciente());
        }


    }//GEN-LAST:event_Agregar2ActionPerformed

    private void Regresar4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar4ActionPerformed
        Padre.removeAll();
        Padre.add(PanelAdmin);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_Regresar4ActionPerformed

    private void GUARDARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GUARDARActionPerformed

    }//GEN-LAST:event_GUARDARActionPerformed

    private void ABRIRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ABRIRActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ABRIRActionPerformed

    private void Regresar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar5ActionPerformed
        Padre.removeAll();
        Padre.add(PanelMed);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);// TODO add your handling code here:
    }//GEN-LAST:event_Regresar5ActionPerformed

    private void BtnPaciente1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPaciente1MouseEntered
        BtnPaciente1.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_BtnPaciente1MouseEntered

    private void BtnPaciente1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPaciente1MouseExited
        BtnPaciente1.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnPaciente1MouseExited

    private void BtnPaciente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnPaciente1ActionPerformed
        Padre.removeAll();
        Padre.add(AggPac2);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);
        cargarDatos();
    }//GEN-LAST:event_BtnPaciente1ActionPerformed

    private void BtnBuscarMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscarMouseEntered
        BtnBuscar.setBackground(Color.LIGHT_GRAY);// TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscarMouseEntered

    private void BtnBuscarMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscarMouseExited
        BtnBuscar.setBackground(new Color(0, 153, 153));   // TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscarMouseExited

    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        Padre.removeAll();
        Padre.add(BuscarPac2);
        trsFiltro = new TableRowSorter(jTable2.getModel());
        jTable2.setRowSorter(trsFiltro);
        if (jTextField5.getText().isBlank()) {
            jTextField5.setEnabled(false);
            jTextField4.setEnabled(false);
            jTextField3.setEnabled(false);
            jTextField1.setEnabled(false);
            jTextField6.setEnabled(false);
            jTextField7.setEnabled(false);
            jTextField8.setEnabled(false);
            jTextField9.setEnabled(false);
            jTextArea1.setEnabled(false);
            jComboBox2.setEnabled(false);
            jComboBox3.setEnabled(false);
            jComboBox4.setEnabled(false);
    }//GEN-LAST:event_BtnBuscarActionPerformed
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);
    }// TODO add your handling code here:

    private void BtnCerrarSesion1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCerrarSesion1MouseClicked
        cerrarSesion();
    }//GEN-LAST:event_BtnCerrarSesion1MouseClicked

    private void BtnCerrarSesion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCerrarSesion1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnCerrarSesion1ActionPerformed

    private void SelecGenero3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelecGenero3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelecGenero3ActionPerformed

    private void PasarHab2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PasarHab2ActionPerformed
        int eli = Tabla6.getSelectedRow();

        if (eli != -1) {
            int id = Integer.parseInt((String) Tabla6.getValueAt(eli, 0));
            if (!Hospital.getPacientes().obtenerPaciente(id).isEnhabitacion()) {
                String[] pisos = {"1", "2", "3"};
                String habitaciones[] = {"01", "02", "03", "04"};
                int piso = JOptionPane.showOptionDialog(null, "Elige un piso:", "Clinica",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, pisos, null);
                piso++;
                while (piso == 0) {
                    piso = JOptionPane.showOptionDialog(null, "Elige un piso:", "Clinica",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.ERROR_MESSAGE, null, pisos, null);
                    piso++;
                }
                for (int i = 0; i < habitaciones.length; i++) {
                    habitaciones[i] = piso + habitaciones[i];
                }
                int habitacion = JOptionPane.showOptionDialog(null, "Elige una habitación:", "Clinica",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, habitaciones, null);
                habitacion++;
                while (habitacion == 0) {
                    habitacion = JOptionPane.showOptionDialog(null, "Elige una habitación:", "Clinica",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, habitaciones, null);
                    habitacion++;
                }
                if (Hospital.getHabitaciones()[piso - 1][habitacion - 1].getMedico() == null) {
                    JOptionPane.showMessageDialog(null, "El paciente No se puede añadir, No hay Medico que Atienda");
                } else {
                    if (Hospital.getHabitaciones()[piso - 1][habitacion - 1].isEstado()) {
                        Paciente tmp = Hospital.getPacientes().obtenerPaciente(id);
                        String valor = Hospital.getHabitaciones()[piso - 1][habitacion - 1].AnadirP(tmp);
                        if (!valor.equals("No se puede añadir, camillas ocupadas")) {
                            tmp.setEnhabitacion(true);
                            PersonalMedico tmpMed = Hospital.getHabitaciones()[piso - 1][habitacion - 1].getMedico();
                            String medico = tmpMed.getNombre() + "      Especialidad: " + tmpMed.getEspecialidad();
                            String confirmaHab = piso + "0" + habitacion;
                            JOptionPane.showMessageDialog(null, valor + " en la habitacion:" + confirmaHab + "\nUbicado en la Camilla: " + tmp.getHabitacion()[2] + "\n <<<<<<<<<<<<Medico De Atención:>>>>>>>>>>>>\n" + "Nombre: " + medico);
                            tmp.setMedico(tmpMed);
                            tmp.setPieza(confirmaHab);
                            String g = (tmp.getGenero() == true) ? "Masculino" : "Femenino";
                            Object Datos2[] = {tmp.getNumeroIdentidad(), tmp.getNombre(), tmp.getApellido(), tmp.getEdad(), tmp.getNumeroTelefono(), "VACIO", confirmaHab, tmp.getHabitacion()[2]};
                            llenarTabla(jTable2, Datos2);

                        } else {
                            JOptionPane.showMessageDialog(null, "No se ha logrado añadir al paciente a la habitacion");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No puede agregar pacientes en una habitacion deshabilitada");

                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "El paciente no se puede añadir ya se encuentra en una habitación");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se puede añadir, no se ha seleccionado ningún paciente");
        }
    }//GEN-LAST:event_PasarHab2ActionPerformed

    private void jRadioButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton7ActionPerformed
        jRadioButton7.setSelected(true);
        {
            jRadioButton8.setSelected(false);
        }
    }//GEN-LAST:event_jRadioButton7ActionPerformed

    private void jRadioButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton8ActionPerformed
        jRadioButton7.setSelected(false);
        {
            jRadioButton8.setSelected(true);
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jRadioButton8ActionPerformed

    private void Agregar5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Agregar5ActionPerformed
        // TODO add your handling code here:
        String id = textField28.getText();
        String nombre = textField23.getText();
        String apellido = textField24.getText();
        String edad = textField25.getText();
        String genero = (String) (SelecGenero3.getSelectedItem());
        String Eps = (String) (SelecEps1.getSelectedItem());
        String correo = textField26.getText();
        String telefono = textField27.getText();
        boolean g = (genero.equals("Masculino") ? true : false);
        String Datos[] = {id, nombre, apellido, edad, genero, Eps};

        if (confirmacionMenuPaciente2().equals("")) {
            JOptionPane.showMessageDialog(null, "El paciente Ha Sido Añadido Éxitosamente Al Hospital");
            llenarTabla(Tabla6, Datos);
            llenarTabla(Tabla3, Datos);
            Paciente paciente = new Paciente(correo, null, null, Eps, true, 0, 0, nombre, apellido, g, Integer.parseInt(edad), Integer.parseInt(id), Long.parseLong(telefono));
            Hospital.getPacientes().registrarPaciente(paciente);
            textField28.setText("");  // TODO add your handling code here:
            textField23.setText("");  // TODO add your handling code here:
            textField24.setText("");  // TODO add your handling code here:
            textField25.setText("");  // TODO add your handling code here:
            textField26.setText("");  // TODO add your handling code here:
            textField27.setText("");  // TODO add your handling code here:
            SelecGenero3.setSelectedIndex(0);
            SelecEps1.setSelectedIndex(0);
            jRadioButton7.setSelected(false);
            jRadioButton8.setSelected(false);
        } else {
            JOptionPane.showMessageDialog(null, confirmacionMenuPaciente2());
        }
    }//GEN-LAST:event_Agregar5ActionPerformed

    private void Regresar7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar7ActionPerformed
        Padre.removeAll();
        Padre.add(PanelPersonalAdmini);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);

        // TODO add your handling code here:
    }//GEN-LAST:event_Regresar7ActionPerformed

    private void BtnPaciente2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPaciente2MouseEntered
        BtnPaciente2.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_BtnPaciente2MouseEntered

    private void BtnPaciente2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPaciente2MouseExited
        BtnPaciente2.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnPaciente2MouseExited

    private void BtnPaciente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnPaciente2ActionPerformed
        Padre.removeAll();
        Padre.add(AggPac3);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);

    }//GEN-LAST:event_BtnPaciente2ActionPerformed

    private void BtnBuscar1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscar1MouseEntered
        BtnBuscar1.setBackground(Color.LIGHT_GRAY);// TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscar1MouseEntered

    private void BtnBuscar1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscar1MouseExited
        BtnBuscar1.setBackground(new Color(0, 153, 153));   // TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscar1MouseExited

    private void BtnBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscar1ActionPerformed
        Padre.removeAll();
        Padre.add(BuscarPac2);
        if (jTextField5.getText().isBlank()) {
            trsFiltro = new TableRowSorter(jTable2.getModel());
            jTable2.setRowSorter(trsFiltro);
            jTextField5.setEnabled(false);
            jTextField4.setEnabled(false);
            jTextField3.setEnabled(false);
            jTextField1.setEnabled(false);
            jTextField6.setEnabled(false);
            jTextField7.setEnabled(false);
            jTextField8.setEnabled(false);
            jTextField9.setEnabled(false);
            jTextArea1.setEnabled(false);
            jComboBox2.setEnabled(false);
            jComboBox3.setEnabled(false);
            jComboBox4.setEnabled(false);
        }
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true); // TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscar1ActionPerformed

    private void BtnCerrarSesion2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCerrarSesion2MouseClicked
        cerrarSesion();
    }//GEN-LAST:event_BtnCerrarSesion2MouseClicked

    private void BtnCerrarSesion2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnCerrarSesion2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnCerrarSesion2ActionPerformed

    private void Regresar8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar8ActionPerformed
        if (jTextField5.getText().isBlank()) {
            buscarID.setText("");
            Empleado emp = (Empleado) ingreso2;
            switch (emp.getCargo()) {
                case "Admin":
                    this.showPanelAdmin();

                    break;
                case "Administrativo":
                    this.showPanelAdmini();
                    break;
                case "Medico":
                    this.showPanelMed();
                    break;
                default:
                    throw new AssertionError();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Primero Guarda El Paciente");
        }
    }//GEN-LAST:event_Regresar8ActionPerformed

    private void BtnBuscar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscar1MouseClicked
    }//GEN-LAST:event_BtnBuscar1MouseClicked

    private void BtnBuscar1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscar1MousePressed
        BtnBuscar1.setBackground(new Color(0, 153, 153));  // TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscar1MousePressed

    private void BtnPaciente2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPaciente2MousePressed
        BtnPaciente2.setBackground(new Color(0, 153, 153)); // TODO add your handling code here:
    }//GEN-LAST:event_BtnPaciente2MousePressed

    private void BtnBuscarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnBuscarMousePressed
        BtnBuscar.setBackground(new Color(0, 153, 153)); // TODO add your handling code here:
    }//GEN-LAST:event_BtnBuscarMousePressed

    private void BtnPaciente1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPaciente1MousePressed
        BtnPaciente1.setBackground(new Color(0, 153, 153));  // TODO add your handling code here:
    }//GEN-LAST:event_BtnPaciente1MousePressed

    private void BtnPacienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPacienteMousePressed
        BtnPaciente.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnPacienteMousePressed

    private void BtnDoctorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnDoctorMousePressed
        BtnDoctor.setBackground(new Color(0, 153, 153)); // TODO add your handling code here:
    }//GEN-LAST:event_BtnDoctorMousePressed

    private void BtnPersonalAdminMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnPersonalAdminMousePressed
        BtnPersonalAdmin.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnPersonalAdminMousePressed

    private void BtnInhabilitarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInhabilitarMousePressed
        BtnInhabilitar.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnInhabilitarMousePressed

    private void BtnCamillaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnCamillaMousePressed
        BtnCamilla.setBackground(new Color(0, 153, 153));// TODO add your handling code here:
    }//GEN-LAST:event_BtnCamillaMousePressed

    private void SelecEpsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelecEpsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelecEpsActionPerformed

    private void textField29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField29ActionPerformed

    private void textField30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField30ActionPerformed

    private void textField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField31ActionPerformed

    private void textField32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField32ActionPerformed

    private void jTextField2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTextField2MousePressed
        if (jTextField2.getText().equals("Ingrese Su Nombre De Usuario")) {
            jTextField2.setText("");
            jTextField2.setForeground(Color.black);
        }

        if (String.valueOf(jPasswordField1.getPassword()).isEmpty()) {
            jPasswordField1.setText("******");
            jPasswordField1.setForeground(Color.gray);
        }
    }//GEN-LAST:event_jTextField2MousePressed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jPasswordField1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPasswordField1MousePressed
        if (String.valueOf(jPasswordField1.getPassword()).equals("******")) {
            jPasswordField1.setText("");
            jPasswordField1.setForeground(Color.black);
        }
        if (jTextField2.getText().isEmpty()) {// TODO add your handling code here:
            jTextField2.setText("Ingrese Su Nombre De Usuario");
            jTextField2.setForeground(Color.gray);
        }
    }//GEN-LAST:event_jPasswordField1MousePressed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    }//GEN-LAST:event_jButton1ActionPerformed

    private void textField11KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField11KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32) {
            evt.consume();
        }
    }//GEN-LAST:event_textField11KeyPressed

    private void textField12KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField12KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32) {
            evt.consume();
        }
    }//GEN-LAST:event_textField12KeyPressed

    private void textField13KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField13KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField13KeyPressed

    private void textField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField16ActionPerformed

    private void textField16KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField16KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField16KeyPressed

    private void textField15KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField15KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField15KeyPressed

    private void textField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField11ActionPerformed

    private void textField23KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField23KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32 && ch != 0) {
            evt.consume();
        }
    }//GEN-LAST:event_textField23KeyPressed

    private void textField24KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField24KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32 && ch != 0) {
            evt.consume();
        }
    }//GEN-LAST:event_textField24KeyPressed

    private void textField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField25ActionPerformed

    private void textField25KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField25KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField25KeyPressed

    private void textField28KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField28KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField28KeyPressed

    private void textField27KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField27KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField27KeyPressed

    private void textField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField4ActionPerformed

    private void textField4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField4KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32 && ch != 0) {
            evt.consume();
        }
    }//GEN-LAST:event_textField4KeyPressed

    private void textField7KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField7KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32 && ch != 0) {
            evt.consume();
        }
    }//GEN-LAST:event_textField7KeyPressed

    private void textField8KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField8KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField8KeyPressed

    private void textField10KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField10KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField10KeyPressed

    private void textField9KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField9KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField9KeyPressed

    private void textField3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField3KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField3KeyPressed

    private void textField6KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField6KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField6KeyPressed

    private void textField5KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField5KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 48 || (ch > 57 && ch < 96) || ch > 105) && ch != 8) {
            evt.consume();
        }
    }//GEN-LAST:event_textField5KeyPressed

    private void textField1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField1KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32 && ch != 0) {
            evt.consume();
        }
    }//GEN-LAST:event_textField1KeyPressed

    private void textField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_textField2KeyPressed
        int ch = evt.getKeyCode();
        if ((ch < 65 || ch > 90) && ch != 8 && ch != 32 && ch != 0) {
            evt.consume();
        }
    }//GEN-LAST:event_textField2KeyPressed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        {
        }
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked

        Admin administrador = new Admin("Angel", 1, "1", "Angel", "Barragan", true, 17, 1, 1234565);
        Hospital.getEmpleados().registrarEmpleado(administrador);
        String usuario = jTextField2.getText();
        String contrasena = jPasswordField1.getText();
        if (usuario.isBlank() || contrasena.isBlank() || (!Hospital.getEmpleados().validarSesion(usuario, contrasena))) {
            JOptionPane.showMessageDialog(null, "Usuario Inválido Compruebe de nuevo");
        } else {
            if (Hospital.getEmpleados().validarSesion(usuario, contrasena)) {
                Empleado emp = Hospital.getEmpleados().obtenerEmpleado(usuario);
                switch (emp.getCargo()) {
                    case "Admin":
                        JOptionPane.showMessageDialog(null, "Bienvenido Señor Administrador " + emp.getNombre());
                        this.Nombre.setText(" Nombre: " + emp.getNombre());
                        this.Cargo.setText(" Cargo: " + emp.getCargo());
                        this.showPanelAdmin();
                        ingreso2 = emp;

                        break;
                    case "Administrativo":
                        JOptionPane.showMessageDialog(null, "Bienvenido " + emp.getCargo() + " " + emp.getNombre());
                        this.Nombre3.setText(" Nombre: " + emp.getNombre());
                        this.Cargo3.setText(" Cargo: " + ((Personal_Admin) emp).getEspecialidad());
                        this.showPanelAdmini();
                        ingreso2 = emp;
                        break;
                    case "Medico":
                        JOptionPane.showMessageDialog(null, "Bienvenido " + emp.getCargo() + " " + emp.getNombre());
                        this.Nombre2.setText(" Nombre: " + emp.getNombre());
                        this.Cargo2.setText(" Esp : " + ((PersonalMedico) emp).getEspecialidad());
                        this.showPanelMed();
                        ingreso2 = emp;
                        ingreso = emp;
                        break;
                    default:
                        throw new AssertionError();
                }
                limpiar();
            }
        }
    }//GEN-LAST:event_jButton1MouseClicked

    private void textField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_textField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_textField13ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void buscarIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_buscarIDActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        Empleado emp = (Empleado) ingreso2;
        switch (emp.getCargo()) {
            case "Admin":
                Modificar();
                break;
            case "Administrativo":
                Modificar();
                break;
            case "Medico":
                ModificarMed();        // TODO add your handling code here:
                break;
            default:
                throw new AssertionError();
        }

    }//GEN-LAST:event_jButton2MouseClicked

    private void ELIMINARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ELIMINARActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ELIMINARActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        if (jTable2.getSelectedRow() == -1) {
            JOptionPane.showMessageDialog(null, "No Se Puede Guardar Ningún Paciente");
        } else if (jTable2.getSelectedRow() != -1 && jTextField3.getText().isBlank()) {
            JOptionPane.showMessageDialog(null, "No Se Puede Guardar Ningún Paciente");

        } else {
            Empleado emp = (Empleado) ingreso2;
            switch (emp.getCargo()) {
                case "Admin":
                    Guardar();
                    break;
                case "Administrativo":
                    Guardar();
                    break;
                case "Medico":
                    GuardarMed();        // TODO add your handling code here:
                    break;
                default:
                    throw new AssertionError();
            }

        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void BtnInformeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInformeMouseEntered
        BtnInforme.setBackground(Color.LIGHT_GRAY);
    }//GEN-LAST:event_BtnInformeMouseEntered

    private void BtnInformeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInformeMouseExited
        BtnInforme.setBackground(new Color(0, 153, 153));        // TODO add your handling code here:
    }//GEN-LAST:event_BtnInformeMouseExited

    private void BtnInformeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnInformeMousePressed
        BtnInforme.setBackground(new Color(0, 153, 153));  // TODO add your handling code here:
    }//GEN-LAST:event_BtnInformeMousePressed

    private void BtnInformeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnInformeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnInformeActionPerformed

    private void buscarIDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_buscarIDKeyTyped
        trsFiltro = new TableRowSorter(jTable2.getModel());
        jTable2.setRowSorter(trsFiltro);
    }//GEN-LAST:event_buscarIDKeyTyped

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        buscarID.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String cadena = buscarID.getText();
                buscarID.setText(cadena);
                repaint();
                filtro();
            }
        });

        // TODO add your handling code here:
    }//GEN-LAST:event_BuscarActionPerformed

    private void AutomatizadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AutomatizadoActionPerformed
        textField16.setText("1117499773");
        textField11.setText("Angel");
        textField12.setText("Barragan Cotacio");
        textField13.setText("18");
        textField15.setText("3227575273");
        textField14.setText("barraganangelmauricio@gmail.com");
        SelecGenero2.setSelectedItem("MASCULINO");
        SelecEps.setSelectedItem("NUEVA EPS");// TODO add your handling code here:
    }//GEN-LAST:event_AutomatizadoActionPerformed

    private void AutomaticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AutomaticoActionPerformed
        textField6.setText("17187448");
        textField1.setText("Daniel");
        textField2.setText("Feria Gordillo");
        textField3.setText("18");
        textField5.setText("3188231060");
        SelecGenero.setSelectedItem("MASCULINO");
        SelecEspe.setSelectedItem("TERAPEUTA");
        textField29.setText("Feria");
        textField30.setText("1");// TODO add your handling code here:
    }//GEN-LAST:event_AutomaticoActionPerformed

    public void filtro() {
        filtro = buscarID.getText();
        trsFiltro.setRowFilter(RowFilter.regexFilter(buscarID.getText(), 0, 1));
    }

    public void showPanelMed() {
        Padre.removeAll();
        Padre.add(PanelMed);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);

    }

    public void showPanelAdmini() {
        Padre.removeAll();
        Padre.add(PanelPersonalAdmini);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);

    }

    public void showPanelAdmin() {
        Padre.removeAll();
        Padre.add(PanelAdmin);
        Padre.repaint();
        Padre.revalidate();
        this.setVisible(true);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Clinica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Clinica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Clinica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Clinica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Clinica().setVisible(true);

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ABRIR;
    private javax.swing.JPanel AggPac1;
    private javax.swing.JPanel AggPac2;
    private javax.swing.JPanel AggPac3;
    private javax.swing.JPanel AggPersonalAdmini;
    private javax.swing.JPanel AggPersonalMed;
    private javax.swing.JButton Agregar;
    private javax.swing.JButton Agregar1;
    private javax.swing.JButton Agregar2;
    private javax.swing.JButton Agregar5;
    private javax.swing.JButton Automatico;
    private javax.swing.JButton Automatizado;
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnBuscar1;
    private javax.swing.JButton BtnCamilla;
    private javax.swing.JButton BtnCerrarSesion;
    private javax.swing.JButton BtnCerrarSesion1;
    private javax.swing.JButton BtnCerrarSesion2;
    private javax.swing.JButton BtnDoctor;
    private javax.swing.JButton BtnInforme;
    private javax.swing.JButton BtnInhabilitar;
    private javax.swing.JButton BtnPaciente;
    private javax.swing.JButton BtnPaciente1;
    private javax.swing.JButton BtnPaciente2;
    private javax.swing.JButton BtnPersonalAdmin;
    private javax.swing.JButton Buscar;
    private javax.swing.JPanel BuscarPac2;
    private javax.swing.JLabel Cargo;
    private javax.swing.JLabel Cargo2;
    private javax.swing.JLabel Cargo3;
    private javax.swing.JButton ELIMINAR;
    private javax.swing.JButton Eliminar;
    private javax.swing.JButton Eliminar1;
    private javax.swing.JButton GUARDAR;
    private javax.swing.JPanel HabitacionesCompletas;
    private javax.swing.JPanel InhHab;
    private javax.swing.JLabel Nombre;
    private javax.swing.JLabel Nombre2;
    private javax.swing.JLabel Nombre3;
    private javax.swing.JPanel Padre;
    private javax.swing.JPanel PanelAdmin;
    private javax.swing.JPanel PanelLogin;
    private javax.swing.JPanel PanelMed;
    private javax.swing.JPanel PanelPersonalAdmini;
    private javax.swing.JButton PasarHa;
    private javax.swing.JButton PasarHab2;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton Regresar1;
    private javax.swing.JButton Regresar2;
    private javax.swing.JButton Regresar4;
    private javax.swing.JButton Regresar5;
    private javax.swing.JButton Regresar7;
    private javax.swing.JButton Regresar8;
    private javax.swing.JComboBox<String> SelecCargo;
    private javax.swing.JComboBox<String> SelecEps;
    private javax.swing.JComboBox<String> SelecEps1;
    private javax.swing.JComboBox<String> SelecEspe;
    private javax.swing.JComboBox<String> SelecGenero;
    private javax.swing.JComboBox<String> SelecGenero1;
    private javax.swing.JComboBox<String> SelecGenero2;
    private javax.swing.JComboBox<String> SelecGenero3;
    private javax.swing.JComboBox<String> SelecGenero4;
    private javax.swing.JTable Tabla1;
    private javax.swing.JTable Tabla2;
    private javax.swing.JTable Tabla3;
    private javax.swing.JTable Tabla5;
    private javax.swing.JTable Tabla6;
    private javax.swing.JTextField buscarID;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel100;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JLabel jLabel103;
    private javax.swing.JLabel jLabel104;
    private javax.swing.JLabel jLabel105;
    private javax.swing.JLabel jLabel106;
    private javax.swing.JLabel jLabel107;
    private javax.swing.JLabel jLabel108;
    private javax.swing.JLabel jLabel109;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel110;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel113;
    private javax.swing.JLabel jLabel114;
    private javax.swing.JLabel jLabel115;
    private javax.swing.JLabel jLabel116;
    private javax.swing.JLabel jLabel117;
    private javax.swing.JLabel jLabel118;
    private javax.swing.JLabel jLabel119;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel120;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JLabel jLabel125;
    private javax.swing.JLabel jLabel126;
    private javax.swing.JLabel jLabel127;
    private javax.swing.JLabel jLabel128;
    private javax.swing.JLabel jLabel129;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel130;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JLabel jLabel82;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel84;
    private javax.swing.JLabel jLabel85;
    private javax.swing.JLabel jLabel86;
    private javax.swing.JLabel jLabel87;
    private javax.swing.JLabel jLabel88;
    private javax.swing.JLabel jLabel89;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel92;
    private javax.swing.JLabel jLabel93;
    private javax.swing.JLabel jLabel94;
    private javax.swing.JLabel jLabel95;
    private javax.swing.JLabel jLabel96;
    private javax.swing.JLabel jLabel97;
    private javax.swing.JLabel jLabel98;
    private javax.swing.JLabel jLabel99;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JPanel pHabitacionJPanel;
    private java.awt.TextArea textArea1;
    private java.awt.TextField textField1;
    private java.awt.TextField textField10;
    private java.awt.TextField textField11;
    private java.awt.TextField textField12;
    private java.awt.TextField textField13;
    private java.awt.TextField textField14;
    private java.awt.TextField textField15;
    private java.awt.TextField textField16;
    private java.awt.TextField textField17;
    private java.awt.TextField textField18;
    private java.awt.TextField textField19;
    private java.awt.TextField textField2;
    private java.awt.TextField textField20;
    private java.awt.TextField textField21;
    private java.awt.TextField textField22;
    private java.awt.TextField textField23;
    private java.awt.TextField textField24;
    private java.awt.TextField textField25;
    private java.awt.TextField textField26;
    private java.awt.TextField textField27;
    private java.awt.TextField textField28;
    private java.awt.TextField textField29;
    private java.awt.TextField textField3;
    private java.awt.TextField textField30;
    private java.awt.TextField textField31;
    private java.awt.TextField textField32;
    private java.awt.TextField textField4;
    private java.awt.TextField textField5;
    private java.awt.TextField textField6;
    private java.awt.TextField textField7;
    private java.awt.TextField textField8;
    private java.awt.TextField textField9;
    // End of variables declaration//GEN-END:variables
}
