
package Clases;


public class Admin extends Empleado {
   

    public Admin(String usuario, int CodigoEmpleado, String contraseña, String nombre, String apellido, boolean genero, int edad, int numeroIdentidad, long numeroTelefono) {
        super(usuario, CodigoEmpleado, contraseña, nombre, apellido, genero, edad, numeroIdentidad, numeroTelefono);
        this.setCargo("Admin");
    }
   }
