package Clases;

public abstract class Persona {

    private String nombre, apellido;
    private boolean genero;
    private int edad;
    private long numeroIdentidad;
    private long numeroTelefono;

    public Persona(String nombre, String apellido, boolean genero, int edad, long numeroIdentidad, long numeroTelefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.genero = genero;
        this.edad = edad;
        this.numeroIdentidad = numeroIdentidad;
        this.numeroTelefono = numeroTelefono;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public boolean getGenero() {
        return genero;
    }

    public int getEdad() {
        return edad;
    }

    public long getNumeroIdentidad() {
        return numeroIdentidad;
    }

    public long getNumeroTelefono() {
        return numeroTelefono;
    }
    

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellido=" + apellido + ", genero=" + genero + ", edad=" + edad + ", numeroIdentidad=" + numeroIdentidad + ", numeroTelefono=" + numeroTelefono + '}';
    }

    public boolean isGenero() {
        return genero;
    }

    public void setGenero(boolean genero) {
        this.genero = genero;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setNumeroIdentidad(long numeroIdentidad) {
        this.numeroIdentidad = numeroIdentidad;
    }

    public void setNumeroTelefono(long numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }

}
