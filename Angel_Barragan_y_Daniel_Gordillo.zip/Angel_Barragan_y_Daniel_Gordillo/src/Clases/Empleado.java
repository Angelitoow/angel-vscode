package Clases;

public class Empleado extends Persona {

    private String usuario;
    private int CodigoEmpleado;
    private String contrasena;
    private String cargo;

    public Empleado(String usuario, int CodigoEmpleado, String contrasena, String nombre, String apellido, boolean genero, int edad, int numeroIdentidad, long numeroTelefono) {
        super(nombre, apellido, genero, edad, numeroIdentidad, numeroTelefono);
        this.usuario = usuario;
        this.CodigoEmpleado = CodigoEmpleado;
        this.contrasena = contrasena;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getCodigoEmpleado() {
        return CodigoEmpleado;
    }

    public void setCodigoEmpleado(int CodigoEmpleado) {
        this.CodigoEmpleado = CodigoEmpleado;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

}
