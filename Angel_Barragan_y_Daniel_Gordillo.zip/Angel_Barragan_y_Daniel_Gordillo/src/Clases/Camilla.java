package Clases;

public class Camilla {

    private boolean estado;
    private Paciente paciente;

    public Camilla() {

    }

    public boolean isEstado() {
        return estado;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        if (paciente != null) {
            estado = true;
            this.paciente = paciente;
        } else {
            this.paciente = null;
            this.estado = false;
        }
    }

    @Override
    public String toString() {
        return "Camilla{" +"estado=" + estado + ", paciente=" + paciente + '}';
    }
    
}
