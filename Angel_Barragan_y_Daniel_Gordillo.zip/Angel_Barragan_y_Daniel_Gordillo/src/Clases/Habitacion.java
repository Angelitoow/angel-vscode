package Clases;

public class Habitacion {

    private int numeroHabitacion;
    private Camilla[] camillas = new Camilla[5];
    private PersonalMedico medico;
    private boolean estado;
    private int numDeCamillas;

    public Habitacion(int numeroHabitacion) {
        this.estado = true;
        this.numDeCamillas = 0;
        this.numeroHabitacion = numeroHabitacion;
        for (int i = 0; i < (int) (Math.random() * 5) + 1; i++) {
            camillas[i] = new Camilla();
            numDeCamillas++;
        }
    }

    public Habitacion() {
        this.estado = true;
        this.numDeCamillas = 0;
        for (int i = 0; i < (int) (Math.random() * 5) + 1; i++) {
            camillas[i] = new Camilla();
            numDeCamillas++;
        }
    }

    public int getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public void setNumeroHabitacion(int numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public Camilla[] getCamillas() {
        return camillas;
    }

    public PersonalMedico getMedico() {
        return medico;
    }

    public void setMedico(PersonalMedico medico) {
        this.medico = medico;

    }

    public String AnadirP(Paciente enfermo) {
        for (int i = 0; i < camillas.length; i++) {
            if (camillas[i] != null) {
                if (!camillas[i].isEstado()) {
                    camillas[i].setPaciente(enfermo);
                    enfermo.getHabitacion()[2] = i + 1;
                    return "El paciente Ha sido Añadido Exitosamente";
                }
            }
        }

        return "No se puede añadir, camillas ocupadas";

    }

    public String BuscarP(long numero) {
        for (int i = 0; i < camillas.length; i++) {
            if (camillas[i] != null && camillas[i].getPaciente().getNumeroIdentidad() == numero) {
                return "En la camilla " + i;
            }
        }

        return "No se encuentra en esta habitacion";
    }

    public int buscarPorAmbos(String criterio) {
        for (int i = 0; i < camillas.length; i++) {
            if (camillas[i] != null && ((camillas[i].getPaciente().getNumeroIdentidad() + "").equals(criterio) || camillas[i].getPaciente().getNombre().equalsIgnoreCase(criterio))) {
                return i;
            }
        }
        return -1;
    }

    public String buscar(long id) {
        String mostrar = "";

        for (int i = 0; i < camillas.length; i++) {
            if (camillas[i] != null && camillas[i].getPaciente().getNumeroIdentidad() == id) {
                mostrar += camillas[i];
            }
        }
        return "";
    }

    public int buscar(String nombre) {
        for (int i = 0; i < camillas.length; i++) {
            if (camillas[i] != null && camillas[i].getPaciente().getNombre().equalsIgnoreCase(nombre)) {
                return i;
            }
        }
        return -1;
    }

//    public Paciente darAlta(long id) {
//        int camilla = this.buscar(id);
//        if (camilla != -1) {
//            Camilla tmp = camillas[camilla];
//            camillas[camilla].setPaciente(null);
//            return tmp.getPaciente();
//        }
//        return null;
//    }
    public boolean addCamilla() {
        if (numDeCamillas <= 4) {
            for (int i = 0; i < camillas.length; i++) {
                if (camillas[i] == null) {
                    camillas[i] = new Camilla();
                    numDeCamillas++;
                    return true;
                }

            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "\n<<<<<<<<<<<<<<<<<<<<HABITACION " + numeroHabitacion + ">>>>>>>>>>>>>>>>>>>" + "\n ----------------------CAMILLA--------------------------------\n " + "Medico General de la Habitacion = " + medico + "\n" + numDeCamillas + ']' + "\n";
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getNumDeCamillas() {
        return numDeCamillas;
    }

    public void setNumDeCamillas(int numDeCamillas) {
        this.numDeCamillas = numDeCamillas;
    }

}
