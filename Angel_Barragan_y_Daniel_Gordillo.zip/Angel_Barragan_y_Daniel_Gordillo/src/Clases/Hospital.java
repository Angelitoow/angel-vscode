package Clases;

import BaseDeDatos.*;

public class Hospital {

    private String nombre;
    static private Habitacion habitaciones[][] = new Habitacion[3][4];
    private Admin administrador;
    static private DatosPacientes pacientes = new DatosPacientes();
    static private DatosEmpleados empleados = new DatosEmpleados();

    static public Habitacion[][] getHabitaciones() {
        return habitaciones;
    }

    public Hospital() {
        this.nombre = "HOSPITAL ANGEL";
        this.administrador = new Admin("Angelitoow", 1, "18", "Angel", "Acosta", true, 18, 1117499773, 3227575273L);
        for (int i = 0; i < habitaciones.length; i++) {
            for (int j = 0; j < habitaciones[i].length; j++) {
                habitaciones[i][j] = new Habitacion((i + 1) * 100 + (j + 1));

            }

        }
    }

    public String getNombre() {
        return nombre;
    }

    public Admin getAdministrador() {
        return administrador;
    }

    public static DatosPacientes getPacientes() {
        return pacientes;
    }

    public static DatosEmpleados getEmpleados() {
        return empleados;
    }

    public String buscarUnPac(long id) {
        String mostrar = "";
        for (int i = 0; i < habitaciones.length; i++) {
            for (int j = 0; j < habitaciones[i].length; j++) {
                if (habitaciones[i][j] != null) {
                    mostrar += habitaciones[i][j].BuscarP(id);
                }
            }

        }

        return mostrar;
    }

    


    static public boolean IngresarMed(PersonalMedico medico) {

        for (int i = 0; i < habitaciones.length; i++) {
            for (int j = 0; j < habitaciones[i].length; j++) {
                if (habitaciones[i][j].getMedico() == null && habitaciones[i][j].isEstado()) {
                    habitaciones[i][j].setMedico(medico);
                    int[] pos = {i, j};
                    habitaciones[i][j].getMedico().setHabitacion(pos);
                    return true;

                }

            }

        }

        return false;
    }
}
