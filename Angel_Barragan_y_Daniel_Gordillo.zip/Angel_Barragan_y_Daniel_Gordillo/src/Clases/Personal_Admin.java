package Clases;

public class Personal_Admin extends Empleado {
    private String especialidad;

    public Personal_Admin(String especialidad,String usuario, int CodigoEmpleado, String contraseña, String nombre, String apellido, boolean genero, int edad, int numeroIdentidad, long numeroTelefono) {
        super(usuario, CodigoEmpleado, contraseña, nombre, apellido, genero, edad, numeroIdentidad, numeroTelefono);
        this.setCargo("Administrativo");
        this.especialidad = especialidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    
    
}
