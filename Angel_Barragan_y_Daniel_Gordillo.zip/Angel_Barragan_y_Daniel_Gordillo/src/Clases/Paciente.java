
package Clases;


public class Paciente extends Persona {

    private String correo,diagnostico,tipoSangre,Eps;
    private boolean estado;
    private float peso,estatura;
    private PersonalMedico medico;
    private int habitacion[]={-1,-1,-1};
    private boolean enhabitacion;
    private String pieza;
    

    public Paciente(String correo, String diagnostico, String tipoSangre, String Eps, boolean estado, float peso, float estatura, String nombre, String apellido, boolean genero, int edad, int numeroIdentidad, long numeroTelefono) {
        super(nombre, apellido, genero, edad, numeroIdentidad, numeroTelefono);
        this.correo = correo;
        this.diagnostico = diagnostico;
        this.tipoSangre = tipoSangre;
        this.Eps = Eps;
        this.estado = estado;
        this.peso = peso;
        this.estatura = estatura;
    }
    
    
    public int[] getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(int[] habitacion) {
        this.habitacion = habitacion;
    }
    
    
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getTipoSangre() {
        return tipoSangre;
    }

    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }
    
    public void setMedico(PersonalMedico medico){
        this.medico = medico;
    }

    public boolean isEnhabitacion() {
        return enhabitacion;
    }

    public void setEnhabitacion(boolean enhabitacion) {
        this.enhabitacion = enhabitacion;
    }

    public String getEps() {
        return Eps;
    }

    public void setEps(String Eps) {
        this.Eps = Eps;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getEstatura() {
        return estatura;
    }

    public void setEstatura(float estatura) {
        this.estatura = estatura;
    }
    

    @Override
    public String toString() {
        return super.toString()+" correo=" + correo + ", diagnostico=" + diagnostico + ", tipoSangre=" + tipoSangre + ", Eps=" + Eps + ", estado=" + estado + ", peso=" + peso + ", estatura=" + estatura + " Medico: "+medico+ " Habitación: "+pieza;
    }

    public String getPieza() {
        return pieza;
    }

    public void setPieza(String pieza) {
        this.pieza = pieza;
    }

    
  
}
