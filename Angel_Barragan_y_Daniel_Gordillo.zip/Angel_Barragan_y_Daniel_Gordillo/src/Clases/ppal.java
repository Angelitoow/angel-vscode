package Clases;

/**
 *
 * @author yacke
 */
public class ppal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a =5;
        String b = "tonto";
        
        Hospital cli = new Hospital();
        Habitacion hab = new Habitacion();
        Object arreglo[] ={a,b};
        System.out.println(arreglo);
    }
}
