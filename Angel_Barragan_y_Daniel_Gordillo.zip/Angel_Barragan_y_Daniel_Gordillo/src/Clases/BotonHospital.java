package Clases;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;

public class BotonHospital extends JButton {

    private int estado = 0; //O = disponible, 1 = seleccionada,  2 = Ocupada

    public int geestado() {
        return estado;
    }

    public void setestado(int activo) {
        this.estado = activo;
    }

    public BotonHospital() {
    }

    public BotonHospital(Icon icon) {
        super(icon);
    }

    public BotonHospital(String text) {
        super(text);
    }

    public BotonHospital(Action a) {
        super(a);
    }

    public BotonHospital(String text, Icon icon) {
        super(text, icon);
    }

}
