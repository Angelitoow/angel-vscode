
package Clases;


public class PersonalMedico extends Empleado {
     private String especialidad;
     private int habitacion[]={-1,-1};
     

    public PersonalMedico(String especialidad, String usuario, int CodigoEmpleado, String contraseña, String nombre, String apellido, boolean genero, int edad, int numeroIdentidad, long numeroTelefono) {
        super(usuario, CodigoEmpleado, contraseña, nombre, apellido, genero, edad, numeroIdentidad, numeroTelefono);
        this.especialidad = especialidad;
        this.setCargo("Medico");
    }

    

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public int[] getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(int[] habitacion) {
        this.habitacion = habitacion;
    }
    

    
    
    
    
    
    
    
    

   

    


    
}
